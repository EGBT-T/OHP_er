﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using SKCOMLib;

namespace OPH_er
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        SKCenterLib _Sign;

        string Account_ID = "";
        
        string Get_ID
        {
            get { return Account_ID; }
            set { Account_ID = value; }
        }

        public MainWindow()
        {
            _Sign = new SKCenterLib();

            InitializeComponent();
        }

        private void Sign_btn_Click(object sender, RoutedEventArgs e)
        {
            if (Account_txt.Text == "" || Password_pbx.Password == "")
            {
                MessageBox.Show("帳號或密碼不可為空白。");
            }
            else
            {
                int _Sign_code = _Sign.SKCenterLib_Login(Account_txt.Text.Trim().ToUpper(), Password_pbx.Password.Trim());
                if (_Sign_code == 0)
                    MessageBox.Show(_Sign_code.ToString());
            }
        }
    }
}
