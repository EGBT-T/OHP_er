﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using SKCOMLib;

namespace OPH_er
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        SKCenterLib _Sign;
        SKOrderLib _Order;
        SKReplyLib _Reply;
        SKQuoteLib _Quote;

        string Account_ID = "";
        string Order_Account = "";

        string Get_ID
        {
            get { return Account_ID; }
            set { Account_ID = value; }
        }

        string Get_Account
        {
            get { return Order_Account; }
            set { Order_Account = value; }
        }

        public MainWindow()
        {
            _Sign = new SKCenterLib();
            _Order = new SKOrderLib();
            _Reply = new SKReplyLib();
            _Quote = new SKQuoteLib();
            
            InitializeComponent();
        }

        private void Sign_btn_Click(object sender, RoutedEventArgs e)
        {
            if (Account_txt.Text == "" || Password_pbx.Password == "")
            {
                MessageBox.Show("帳號或密碼不可為空白。");
            }
            else
            {
                if (Remember_chk.IsChecked == true)
                    _Sign.SKCenterLib_ResetServer("morder1.capital.com.tw");

                int _Sign_code = _Sign.SKCenterLib_Login(Account_txt.Text.Trim().ToUpper(), Password_pbx.Password.Trim());
                if (_Sign_code == 0)
                {
                    ReplyData_lst.Items.Add("登入成功");
                    this.Get_ID = Account_txt.Text.Trim().ToUpper();
                    
                    _Order.OnAccount += new _ISKOrderLibEvents_OnAccountEventHandler(this.OnAccount);
                    _Reply.OnData += new _ISKReplyLibEvents_OnDataEventHandler(this.OnData);
                    int Order_code = _Order.SKOrderLib_Initialize();
                    ReplyData_lst.Items.Add("初始化成功");
                    ReplyData_lst.Items.Add("取得帳號...");
                    int GetAccount_code = _Order.GetUserAccount();
                    int nCode = _Reply.SKReplyLib_ConnectByID(this.Get_ID);
                    ReplyData_lst.Items.Add("回報成功");
                }
            }
        }

        void OnAccount(string Account_ID, string bstrAccountData)
        {
            string[] strValues;
            string strAccount;

            strValues = bstrAccountData.Split(',');
            strAccount = strValues[1] + strValues[3];

            if (strValues[0] == "TS")
            {
                this
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    .Order_Account = strAccount;
                ReplyData_lst.Items.Add("證券帳號：" + strAccount);
            }
        }

        void OnData(string strUserID, string strData)
        {
            ReplyData_lst.Items.Add("{" + strUserID + "}OnNewData:" + strData);
        }
    }
}
