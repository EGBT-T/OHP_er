﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using SKCOMLib;

namespace OPH_er
{
    public partial class Form1 : Form
    {
        SKCenterLib _Center;
        SKOrderLib _Order;
        SKQuoteLib _Quote;

        DataTable Dt = new DataTable("StockTable");

        string Account_ID = "";
        string Order_Account = "";

        public Form1()
        {
            _Center = new SKCenterLib();
            _Order = new SKOrderLib();
            _Quote = new SKQuoteLib();

            InitializeComponent();
            Dt.Columns.Add("股票代號", typeof(string));
            Dt.Columns.Add("條件", typeof(string));
            Dt.Columns.Add("價格", typeof(float));
            Dt.Columns.Add("數量(張)", typeof(string));
            Dt.Columns.Add("執行", typeof(string));
            StopLoss_dgv.DataSource = Dt;
        }

        string Get_ID
        {
            get { return Account_ID; }
            set { Account_ID = value; }
        }

        private void Add_btn_Click(object sender, EventArgs e)
        {
            if (Stockcode_txt.Text == "" || Stockcondition_cmbbx.Text == ""  || StockQty_txt.Text == "" || StockExe_cmbbx.Text == "")
            {
                MessageBox.Show("除了「價格」，其餘不可空白。");
            }
            else
            {
                DataRow Dr = Dt.NewRow();
                Dr["股票代號"] = Stockcode_txt.Text.Trim();
                Dr["條件"] = Stockcondition_cmbbx.SelectedItem;
                if (Stockprice_txt.Text == "")
                {
                    Dr["價格"] = 0;
                }
                else
                {
                    Dr["價格"] = Convert.ToDouble(Stockprice_txt.Text);
                }
                Dr["數量(張)"] = StockQty_txt.Text.Trim();
                Dr["執行"] = StockExe_cmbbx.SelectedItem;
                Dt.Rows.Add(Dr);
            }
        }

        private void Sign_btn_Click(object sender, EventArgs e)
        {
            int _Signcode = _Center.SKCenterLib_Login(Account_txt.Text.Trim().ToUpper(),Password_txt.Text.Trim());
            if (_Signcode == 0)
            {
                this.Get_ID = Account_txt.Text.Trim().ToUpper();
                MessageBox.Show("登入成功");
                _Order.OnAccount += new _ISKOrderLibEvents_OnAccountEventHandler(Get_OnAccount);
                int _OrderInit = _Order.SKOrderLib_Initialize();
                _Order.GetUserAccount();
                Main_pnl.Visible = true;
            }
        }

        void Get_OnAccount(string bstrLogInID, string bstrAccountData)
        {
            string[] strValues;
            string strAccount;

            strValues = bstrAccountData.Split(',');
            strAccount = strValues[1] + strValues[3];

            if (strValues[0] == "TS")
                Order_Account = strAccount;
        }

        public void ThrowOrder(string Account, string StockID, short BS, string Price, int Qty)
        {
            STOCKORDER S_Order = new STOCKORDER();
            S_Order.bstrFullAccount = Account;
            S_Order.bstrStockNo = StockID;
            S_Order.sPrime = 0;
            S_Order.sPeriod = 0;
            S_Order.sFlag = 0;
            S_Order.sBuySell = BS;
            S_Order.bstrPrice = Price;
            S_Order.nQty = Qty;
        }
    }
}
