﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using SKCOMLib;

namespace OPH_er
{
    public partial class Form1 : Form
    {
        SKCenterLib _Center;
        SKOrderLib _Order;
        SKQuoteLib _Quote;

        DataTable Dt = new DataTable("StockTable");

        public DataTable StockQuoteTable;

        string Account_ID = "";
        string Order_Account = "";

        public Form1()
        {
            _Center = new SKCenterLib();
            _Order = new SKOrderLib();
            _Quote = new SKQuoteLib();

            InitializeComponent();
            Dt.Columns.Add("股票代號", typeof(string));
            Dt.Columns.Add("條件", typeof(string));
            Dt.Columns.Add("價格", typeof(float));
            Dt.Columns.Add("數量(張)", typeof(string));
            Dt.Columns.Add("執行", typeof(string));
            StopLoss_dgv.DataSource = Dt;

            StockQuoteTable = CreateStocksTable();
        }

        public DataTable CreateStocksTable()
        {
            DataTable myDataTable = new DataTable();

            DataColumn myDataColumn;

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.Double");
            myDataColumn.ColumnName = "m_nClose";
            myDataTable.Columns.Add(myDataColumn);

            //myDataTable.PrimaryKey = new DataColumn[] { myDataTable.Columns["m_caStockNo"] };

            return myDataTable;
        }

        string Get_ID
        {
            get { return Account_ID; }
            set { Account_ID = value; }
        }

        private void Add_btn_Click(object sender, EventArgs e)
        {
            if (Stockcode_txt.Text == "" || Stockcondition_cmbbx.Text == ""  || StockQty_txt.Text == "" || StockExe_cmbbx.Text == "")
            {
                MessageBox.Show("除了「價格」，其餘不可空白。");
            }
            else
            {
                DataRow Dr = Dt.NewRow();
                Dr["股票代號"] = Stockcode_txt.Text.Trim();
                Dr["條件"] = Stockcondition_cmbbx.SelectedItem;
                if (Stockprice_txt.Text == "")
                {
                    Dr["價格"] = 0;
                }
                else
                {
                    Dr["價格"] = Convert.ToDouble(Stockprice_txt.Text);
                }
                Dr["數量(張)"] = StockQty_txt.Text.Trim();
                Dr["執行"] = StockExe_cmbbx.SelectedItem;
                Dt.Rows.Add(Dr);
            }
        }

        private void Sign_btn_Click(object sender, EventArgs e)
        {
            int _Signcode = _Center.SKCenterLib_Login(Account_txt.Text.Trim().ToUpper(),Password_txt.Text.Trim());
            if (_Signcode == 0)
            {
                this.Get_ID = Account_txt.Text.Trim().ToUpper();
                listBox1.Items.Add("登入成功");
                _Order.OnAccount += new _ISKOrderLibEvents_OnAccountEventHandler(Get_OnAccount);
                int _OrderInit = _Order.SKOrderLib_Initialize();
                _Order.GetUserAccount();
                Main_pnl.Visible = true;
            }
        }

        void Get_OnAccount(string bstrLogInID, string bstrAccountData)
        {
            string[] strValues;
            string strAccount;

            strValues = bstrAccountData.Split(',');
            strAccount = strValues[1] + strValues[3];

            if (strValues[0] == "TS")
                Order_Account = strAccount;
        }

        public void ThrowOrder(string Account, string StockID, short BS, string Price, int Qty)
        {
            STOCKORDER S_Order = new STOCKORDER();
            S_Order.bstrFullAccount = Account;
            S_Order.bstrStockNo = StockID;
            S_Order.sPrime = 0;
            S_Order.sPeriod = 0;
            S_Order.sFlag = 0;
            S_Order.sBuySell = BS;
            S_Order.bstrPrice = Price;
            S_Order.nQty = Qty;
        }

        private void StopLoss_dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && StopLoss_dgv.RowCount > 1)
                StopLoss_dgv.Rows.RemoveAt(e.RowIndex);
                //(sender as DataGridView).Rows.RemoveAt(e.RowIndex);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            short sPage;

            if (short.TryParse(txtPageNo.Text, out sPage) == false)
                return;


            m_dtStocks.Clear();
            gridStocks.ClearSelection();

            gridStocks.DataSource = m_dtStocks;

            gridStocks.Columns["m_sStockidx"].Visible = false;
            gridStocks.Columns["m_sDecimal"].Visible = false;
            gridStocks.Columns["m_sTypeNo"].Visible = false;
            gridStocks.Columns["m_cMarketNo"].Visible = false;
            gridStocks.Columns["m_caStockNo"].HeaderText = "代碼";
            gridStocks.Columns["m_caName"].HeaderText = "名稱";
            gridStocks.Columns["m_nOpen"].HeaderText = "開盤價";
            //gridStocks.Columns["m_nHigh"].Visible = false;
            gridStocks.Columns["m_nHigh"].HeaderText = "最高";
            //gridStocks.Columns["m_nLow"].Visible = false;
            gridStocks.Columns["m_nLow"].HeaderText = "最低";
            gridStocks.Columns["m_nClose"].HeaderText = "成交價";
            gridStocks.Columns["m_nTickQty"].HeaderText = "單量";
            gridStocks.Columns["m_nRef"].HeaderText = "昨收價";
            gridStocks.Columns["m_nBid"].HeaderText = "買價";
            //gridStocks.Columns["m_nBc"].Visible = false;
            gridStocks.Columns["m_nBc"].HeaderText = "買量";
            gridStocks.Columns["m_nAsk"].HeaderText = "賣價";
            //gridStocks.Columns["m_nAc"].Visible = false;
            gridStocks.Columns["m_nAc"].HeaderText = "賣量";
            //gridStocks.Columns["m_nTBc"].Visible = false;
            gridStocks.Columns["m_nTBc"].HeaderText = "買盤量";
            //gridStocks.Columns["m_nTAc"].Visible = false;
            gridStocks.Columns["m_nTAc"].HeaderText = "賣盤量";
            gridStocks.Columns["m_nFutureOI"].Visible = false;
            //gridStocks.Columns["m_nTQty"].Visible = false;
            gridStocks.Columns["m_nTQty"].HeaderText = "總量";
            //gridStocks.Columns["m_nYQty"].Visible = false;
            gridStocks.Columns["m_nYQty"].HeaderText = "昨量";
            //gridStocks.Columns["m_nUp"].Visible = false;
            gridStocks.Columns["m_nUp"].HeaderText = "漲停";
            //gridStocks.Columns["m_nDown"].Visible = false;
            gridStocks.Columns["m_nDown"].HeaderText = "跌停";

            string[] Stocks = txtStocks.Text.Trim().Split(new Char[] { ',' });

            foreach (string s in Stocks)
            {
                SKSTOCK pSKStock = new SKSTOCK();

                int nCode = m_SKQuoteLib.SKQuoteLib_GetStockByNo(s.Trim(), ref pSKStock);

                OnUpDateDataRow(pSKStock);

                if (nCode == 0)
                {
                    OnUpDateDataRow(pSKStock);
                }
            }

            int m_nCode = m_SKQuoteLib.SKQuoteLib_RequestStocks(ref sPage, txtStocks.Text.Trim());
        }

        private void OnUpDateDataRow(SKSTOCK pStock)
        {

            string strStockNo = pStock.bstrStockNo;

            DataRow drFind = m_dtStocks.Rows.Find(strStockNo);
            if (drFind == null)
            {
                try
                {
                    DataRow myDataRow = m_dtStocks.NewRow();

                    myDataRow["m_sStockidx"] = pStock.sStockIdx;
                    myDataRow["m_sDecimal"] = pStock.sDecimal;
                    myDataRow["m_sTypeNo"] = pStock.sTypeNo;
                    myDataRow["m_cMarketNo"] = pStock.bstrMarketNo;
                    myDataRow["m_caStockNo"] = pStock.bstrStockNo;
                    myDataRow["m_caName"] = pStock.bstrStockName;
                    myDataRow["m_nOpen"] = pStock.nOpen / (Math.Pow(10, pStock.sDecimal));
                    myDataRow["m_nHigh"] = pStock.nHigh / (Math.Pow(10, pStock.sDecimal));
                    myDataRow["m_nLow"] = pStock.nLow / (Math.Pow(10, pStock.sDecimal));
                    myDataRow["m_nClose"] = pStock.nClose / (Math.Pow(10, pStock.sDecimal));
                    myDataRow["m_nTickQty"] = pStock.nTickQty;
                    myDataRow["m_nRef"] = pStock.nRef / (Math.Pow(10, pStock.sDecimal));
                    myDataRow["m_nBid"] = pStock.nBid / (Math.Pow(10, pStock.sDecimal));
                    myDataRow["m_nBc"] = pStock.nBc;
                    myDataRow["m_nAsk"] = pStock.nAsk / (Math.Pow(10, pStock.sDecimal));
                    m_nSimulateStock = pStock.nSimulate;                 //成交價/買價/賣價;揭示
                    myDataRow["m_nAc"] = pStock.nAc;
                    myDataRow["m_nTBc"] = pStock.nTBc;
                    myDataRow["m_nTAc"] = pStock.nTAc;
                    myDataRow["m_nFutureOI"] = pStock.nFutureOI;
                    myDataRow["m_nTQty"] = pStock.nTQty;
                    myDataRow["m_nYQty"] = pStock.nYQty;
                    myDataRow["m_nUp"] = pStock.nUp / (Math.Pow(10, pStock.sDecimal));
                    myDataRow["m_nDown"] = pStock.nDown / (Math.Pow(10, pStock.sDecimal));

                    m_dtStocks.Rows.Add(myDataRow);

                }
                catch (Exception ex)
                {
                    string msg = ex.Message;
                }
            }
            else
            {
                drFind["m_sStockidx"] = pStock.sStockIdx;
                drFind["m_sDecimal"] = pStock.sDecimal;
                drFind["m_sTypeNo"] = pStock.sTypeNo;
                drFind["m_cMarketNo"] = pStock.bstrMarketNo;
                drFind["m_caStockNo"] = pStock.bstrStockNo;
                drFind["m_caName"] = pStock.bstrStockName;
                drFind["m_nOpen"] = pStock.nOpen / (Math.Pow(10, pStock.sDecimal));
                drFind["m_nHigh"] = pStock.nHigh / (Math.Pow(10, pStock.sDecimal));
                drFind["m_nLow"] = pStock.nLow / (Math.Pow(10, pStock.sDecimal));
                drFind["m_nClose"] = pStock.nClose / (Math.Pow(10, pStock.sDecimal));
                drFind["m_nTickQty"] = pStock.nTickQty;
                drFind["m_nRef"] = pStock.nRef / (Math.Pow(10, pStock.sDecimal));
                drFind["m_nBid"] = pStock.nBid / (Math.Pow(10, pStock.sDecimal));
                drFind["m_nBc"] = pStock.nBc;
                drFind["m_nAsk"] = pStock.nAsk / (Math.Pow(10, pStock.sDecimal));
                drFind["m_nAc"] = pStock.nAc;
                drFind["m_nTBc"] = pStock.nTBc;
                drFind["m_nTAc"] = pStock.nTAc;
                drFind["m_nFutureOI"] = pStock.nFutureOI;
                drFind["m_nTQty"] = pStock.nTQty;
                drFind["m_nYQty"] = pStock.nYQty;
                drFind["m_nUp"] = pStock.nUp / (Math.Pow(10, pStock.sDecimal));
                drFind["m_nDown"] = pStock.nDown / (Math.Pow(10, pStock.sDecimal));
            }
        }
    }
}
