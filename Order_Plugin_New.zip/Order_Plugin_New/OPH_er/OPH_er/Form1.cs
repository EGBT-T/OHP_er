﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using SKCOMLib;

namespace OPH_er
{
    public partial class Form1 : Form
    {
        SKCenterLib _Center;
        SKOrderLib _Order;
        SKQuoteLib _Quote;


        public DataTable UserAddTable;
        public DataTable StockQuoteTable;

        string Account_ID = "";
        string Order_Account = "";

        public Form1()
        {
            InitializeComponent();

            _Center = new SKCenterLib();
            _Order = new SKOrderLib();
            _Quote = new SKQuoteLib();

            UserAddTable = CreateUserTable();
            StockQuoteTable = CreateQuoteTable();

            StopLoss_dgv.DataSource = UserAddTable;
        }

        public DataTable CreateUserTable()
        {
            DataTable myDataTable = new DataTable();

            DataColumn myDataColumn;

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "股票代號";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "條件";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.Double");
            myDataColumn.ColumnName = "價格";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "數量(張)";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "執行";
            myDataTable.Columns.Add(myDataColumn);

            return myDataTable;
        }

        public DataTable CreateQuoteTable()
        {
            DataTable myDataTable = new DataTable();

            DataColumn myDataColumn;

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "nStockNo";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.Double");
            myDataColumn.ColumnName = "nClose";
            myDataTable.Columns.Add(myDataColumn);

            myDataTable.PrimaryKey = new DataColumn[] { myDataTable.Columns["nStockNo"] };

            return myDataTable;
        }

        string Get_ID
        {
            get { return Account_ID; }
            set { Account_ID = value; }
        }

        private void Add_btn_Click(object sender, EventArgs e)
        {
            string StockNo = "";
            if (Stockcode_txt.Text == "" || Stockcondition_cmbbx.Text == ""  || StockQty_txt.Text == "" || StockExe_cmbbx.Text == "")
            {
                MessageBox.Show("除了「價格」，其餘不可空白。");
            }
            else
            {
                DataRow Dr = UserAddTable.NewRow();
                Dr["股票代號"] = Stockcode_txt.Text.Trim();
                Dr["條件"] = Stockcondition_cmbbx.SelectedItem;
                if (Stockprice_txt.Text == "")
                {
                    Dr["價格"] = 0;
                }
                else
                {
                    Dr["價格"] = Convert.ToDouble(Stockprice_txt.Text);
                }
                Dr["數量(張)"] = StockQty_txt.Text.Trim();
                Dr["執行"] = StockExe_cmbbx.SelectedItem;
                UserAddTable.Rows.Add(Dr);

                for (int i = 0; i < StopLoss_dgv.RowCount; i++)
                {
                    if (i == 0)
                    {
                        StockNo = StopLoss_dgv.Rows[i].Cells[1].Value.ToString();
                    }
                    else
                    {
                        StockNo = StockNo + "," + StopLoss_dgv.Rows[i].Cells[1].Value.ToString();
                    }
                }
                RequestQuote(StockNo);
            }
        }

        private void RequestQuote(string Data)
        {
            string StockNo = Data;
            short sPage = 1;

            StockQuoteTable.Clear();

            string[] Stocks = StockNo.Trim().Split(new Char[] { ',' });

            foreach (string s in Stocks)
            {
                SKSTOCK QuoteStockStruct = new SKSTOCK();

                int nCode = _Quote.SKQuoteLib_GetStockByNo(s.Trim(), ref QuoteStockStruct);

                OnUpDateDataRow(QuoteStockStruct);

                if (nCode == 0)
                {
                    OnUpDateDataRow(QuoteStockStruct);
                }
            }
            _Quote.SKQuoteLib_RequestStocks(ref sPage, StockNo.Trim());
        }

        private void Sign_btn_Click(object sender, EventArgs e)
        {
            int _Signcode = _Center.SKCenterLib_Login(Account_txt.Text.Trim().ToUpper(),Password_txt.Text.Trim());
            if (_Signcode == 0)
            {
                this.Get_ID = Account_txt.Text.Trim().ToUpper();
                Msg_lst.Items.Add("登入成功");

                _Order.OnAccount += new _ISKOrderLibEvents_OnAccountEventHandler(Get_OnAccount);

                _Quote.OnConnection += new _ISKQuoteLibEvents_OnConnectionEventHandler(Con_OnConnetction);
                _Quote.OnNotifyQuote += new _ISKQuoteLibEvents_OnNotifyQuoteEventHandler(Update_OnNotifyQuote);

                int _OrderInit = _Order.SKOrderLib_Initialize();
                int _QuoteConn = _Quote.SKQuoteLib_EnterMonitor();
                _Order.GetUserAccount();

                //Main_pnl.Visible = true;
            }
        }

        void Con_OnConnetction(int nKind, int nCode)
        {
            if (nKind == 3003)
            {

            }
        }

        void Get_OnAccount(string bstrLogInID, string bstrAccountData)
        {
            string[] strValues;
            string strAccount;

            strValues = bstrAccountData.Split(',');
            strAccount = strValues[1] + strValues[3];

            if (strValues[0] == "TS")
                Order_Account = strAccount;
        }

        private void StopLoss_dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string StockNo = "";
            if (e.ColumnIndex == 0)
            {
                StopLoss_dgv.Rows.RemoveAt(e.RowIndex);
                for (int i = 0; i < StopLoss_dgv.RowCount; i++)
                {
                    if (i == 0)
                    {
                        StockNo = StopLoss_dgv.Rows[i].Cells[1].Value.ToString();
                    }
                    else
                    {
                        StockNo = StockNo + "," + StopLoss_dgv.Rows[i].Cells[1].Value.ToString();
                    }
                }
                RequestQuote(StockNo);
            }

            //(sender as DataGridView).Rows.RemoveAt(e.RowIndex);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //textBox1.Text = (Convert.ToDouble(StockQuoteTable.Rows[0][1])).ToString();//StopLoss_dgv.Rows[0].Cells[2].Value.ToString();
            //textBox1.Text = StockQuoteTable.Rows[0][1].ToString();
        }

        void Update_OnNotifyQuote(short sMarketNo, short sStockIdx)
        {
            SKSTOCK QuoteStockStruct = new SKSTOCK();
            _Quote.SKQuoteLib_GetStockByIndex(sMarketNo, sStockIdx, ref QuoteStockStruct);
            OnUpDateDataRow(QuoteStockStruct);
        }

        private void OnUpDateDataRow(SKSTOCK QuoteStockStruct)
        {
            string strStockNo = QuoteStockStruct.bstrStockNo;

            DataRow drFind = StockQuoteTable.Rows.Find(strStockNo);
            if (drFind == null)
            {
                try
                {
                    DataRow myDataRow = StockQuoteTable.NewRow();

                    myDataRow["nStockNo"] = QuoteStockStruct.bstrStockNo;
                    myDataRow["nClose"] = QuoteStockStruct.nClose / (Math.Pow(10, QuoteStockStruct.sDecimal));

                    StockQuoteTable.Rows.Add(myDataRow);

                }
                catch (Exception ex)
                {
                    //string msg = ex.Message;
                }
            }
            else
            {
                drFind["nStockNo"] = QuoteStockStruct.bstrStockNo;
                drFind["nClose"] = QuoteStockStruct.nClose / (Math.Pow(10, QuoteStockStruct.sDecimal));
                for (int i = 0; i < StopLoss_dgv.RowCount; i++)
                {
                    switch (StopLoss_dgv.Rows[i].Cells[2].Value.ToString())
                    {
                        case "大於等於":
                            {
                                if (Convert.ToDouble( StockQuoteTable.Rows[i][1]) != 0)
                                {
                                    if ((Convert.ToDouble(StockQuoteTable.Rows[i][1]) > Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value)) || (Convert.ToDouble(StockQuoteTable.Rows[i][1]) == Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value)))
                                    {
                                        short BS = 0;
                                        if (StopLoss_dgv.Rows[i].Cells[5].Value.ToString() == "賣出")
                                            BS = 1;

                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[1].Value.ToString(), BS, StopLoss_dgv.Rows[i].Cells[3].Value.ToString(), Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[4].Value));
                                    }
                                }
                                break;
                            }
                        case "小於等於":
                            {
                                if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) != 0)
                                {
                                    if ((Convert.ToDouble(StockQuoteTable.Rows[i][1]) > Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value)) || (Convert.ToDouble(StockQuoteTable.Rows[i][1]) == Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value)))
                                    {
                                        short BS = 0;
                                        if (StopLoss_dgv.Rows[i].Cells[5].Value.ToString() == "賣出")
                                            BS = 1;

                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[1].Value.ToString(), BS, StopLoss_dgv.Rows[i].Cells[3].Value.ToString(), Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[4].Value));
                                    }
                                }
                                break;
                            }
                    }
                }
            }
        }

        private void ThrowOrder(string StockID, short BS, string Price, int Qty)
        {
            STOCKORDER S_Order = new STOCKORDER();
            S_Order.bstrFullAccount = Order_Account;
            S_Order.bstrStockNo = StockID;
            S_Order.sPrime = 0;
            S_Order.sPeriod = 0;
            S_Order.sFlag = 0;
            S_Order.sBuySell = BS;
            S_Order.bstrPrice = Price;
            S_Order.nQty = Qty;
        }
    }
}
