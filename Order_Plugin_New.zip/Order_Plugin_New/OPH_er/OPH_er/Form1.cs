﻿using System;
using System.Data;
using System.Xml;
using System.Windows.Forms;
using System.Linq;

using SKCOMLib;
using System.IO;

namespace OPH_er
{
    public partial class Form1 : Form
    {
        SKCenterLib _Center;
        SKOrderLib _Order;
        SKQuoteLib _Quote;


        public DataTable UserAddTable;
        public DataTable StockQuoteTable;

        OrderModel OrderMode = new OrderModel();

        int _Log = 0;
        string Account_ID = "";
        string Order_Account = "";

        public Form1()
        {
            InitializeComponent();

            _Center = new SKCenterLib();
            _Order = new SKOrderLib();
            _Quote = new SKQuoteLib();

            UserAddTable = CreateUserTable();
            StockQuoteTable = CreateQuoteTable();

            StopLoss_dgv.DataSource = UserAddTable;
        }

        public DataTable CreateUserTable()
        {
            DataTable myDataTable = new DataTable();

            DataColumn myDataColumn;

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "種類";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "股票代號";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "條件";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.Double");
            myDataColumn.ColumnName = "價格";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "方法";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.Double");
            myDataColumn.ColumnName = "掛單價格";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "數量(張)";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "執行";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "狀態(1)";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "停利價格";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "停損價格";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "狀態(2)";
            myDataTable.Columns.Add(myDataColumn);

            return myDataTable;
        }

        public DataTable CreateQuoteTable()
        {
            DataTable myDataTable = new DataTable();

            DataColumn myDataColumn;

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.String");
            myDataColumn.ColumnName = "nStockNo";
            myDataTable.Columns.Add(myDataColumn);

            myDataColumn = new DataColumn();
            myDataColumn.DataType = Type.GetType("System.Double");
            myDataColumn.ColumnName = "nClose";
            myDataTable.Columns.Add(myDataColumn);

            myDataTable.PrimaryKey = new DataColumn[] { myDataTable.Columns["nStockNo"] };

            return myDataTable;
        }

        string Get_ID
        {
            get { return Account_ID; }
            set { Account_ID = value; }
        }

        private void Add_btn_Click(object sender, EventArgs e) {
            var CheckedButton = Intelligent_Grpbx.Controls.OfType<RadioButton>()
                                      .FirstOrDefault(r => r.Checked);

            if (Stockcode_txt.Text == "" || Conditionprice_txt.Text == "" || Stockcondition_cmbbx.Text == "" ||
                OrderPrice_txt.Text == "" || StockQty_txt.Text == "" || StockExe_cmbbx.Text == "") {
                MessageBox.Show("可能漏填了一些資訊。");
                return;
            }

            if (OCO_Radio.Checked && (StopProfit_txt.Text == "" || StopLoss_txt.Text == "")) {
                MessageBox.Show("可能漏填了一些資訊。");
                return;
            }

            switch (CheckedButton.Text) {
                case "觸價單 ( MIT )": {
                        AddNewData(CheckedButton.Text.ToString(),
                                    Stockcode_txt.Text.Trim(),
                                    Stockcondition_cmbbx.SelectedItem.ToString(),
                                    Conditionprice_txt.Text.ToString(),
                                    OrderMethod_cmbbx.SelectedItem.ToString(),
                                    OrderPrice_txt.Text.ToString(),
                                    StockQty_txt.Text.Trim(),
                                    StockExe_cmbbx.SelectedItem.ToString(),
                                    "未執行",
                                    "N/A",
                                    "N/A",
                                    "N/A");
                        ClearSet();
                        break;
                    }
                case "OCO ( One Cancel the Other )": {
                        if (StockExe_cmbbx.SelectedItem.ToString() == "買進") {
                            if (Convert.ToDouble(StopProfit_txt.Text.ToString()) <= Convert.ToDouble(OrderPrice_txt.Text.ToString())
                                || Convert.ToDouble(StopLoss_txt.Text.ToString()) >= Convert.ToDouble(OrderPrice_txt.Text.ToString())) {
                                MessageBox.Show(" 多單 , 停利/停損 價格錯誤。");
                                return;
                            }
                        }
                        else if (StockExe_cmbbx.SelectedItem.ToString() == "賣出") {
                            if ((Convert.ToDouble(StopProfit_txt.Text.ToString()) >= Convert.ToDouble(OrderPrice_txt.Text.ToString()))
                                || (Convert.ToDouble(StopLoss_txt.Text.ToString()) <= Convert.ToDouble(OrderPrice_txt.Text.ToString()))) {
                                MessageBox.Show(" 空單 , 停利/停損 價格錯誤。");
                                return;
                            }
                        }
                        AddNewData(CheckedButton.Text.ToString(),
                                    Stockcode_txt.Text.Trim(),
                                    Stockcondition_cmbbx.SelectedItem.ToString(),
                                    Conditionprice_txt.Text.ToString(),
                                    OrderMethod_cmbbx.SelectedItem.ToString(),
                                    OrderPrice_txt.Text.ToString(),
                                    StockQty_txt.Text.Trim(),
                                    StockExe_cmbbx.SelectedItem.ToString(),
                                    "未執行",
                                    StopLoss_txt.Text.ToString(),
                                    StopProfit_txt.Text.ToString(),
                                    "未執行");
                        ClearSet();
                        break;
                    }
            }
            //if (Stockcode_txt.Text == "" || Conditionprice_txt.Text == "" || Stockcondition_cmbbx.Text == "" ||
            //    OrderPrice_txt.Text == "" || StockQty_txt.Text == "" || StockExe_cmbbx.Text == "")
            //{
            //    MessageBox.Show("可能漏填了一些資訊。");
            //    return;
            //}
            //else
            //{
            //    AddNewData(Stockcode_txt.Text.Trim(),
            //                Stockcondition_cmbbx.SelectedItem.ToString(),
            //                Conditionprice_txt.Text.ToString(),
            //                OrderMethod_cmbbx.SelectedItem.ToString(),
            //                OrderPrice_txt.Text.ToString(),
            //                StockQty_txt.Text.Trim(),
            //                StockExe_cmbbx.SelectedItem.ToString(),
            //                "未執行");

            //    Stockcode_txt.Text = "";
            //    Conditionprice_txt.Text = "";
            //    OrderPrice_txt.Text = "";
            //    StockQty_txt.Text = "";
            //}
        }

        private void ClearSet() {
            foreach (Control Obj in Touch_OCO_Grpbx.Controls) {
                if (Obj is TextBox) {
                    Obj.Text = "";
                }
            }
            foreach (Control Obj in OCO_Grpbx.Controls) {
                if (Obj is TextBox) {
                    Obj.Text = "";
                }
            }
        }

        private void RequestQuote(string Data)
        {
            string StockNo = Data;
            short sPage = 1;

            StockQuoteTable.Clear();

            string[] Stocks = StockNo.Trim().Split(new Char[] { ',' });

            foreach (string s in Stocks)
            {
                SKSTOCK QuoteStockStruct = new SKSTOCK();

                int nCode = _Quote.SKQuoteLib_GetStockByNo(s.Trim(), ref QuoteStockStruct);

                OnUpDateDataRow(QuoteStockStruct);

                if (nCode == 0)
                {
                    OnUpDateDataRow(QuoteStockStruct);
                }
            }
            _Quote.SKQuoteLib_RequestStocks(ref sPage, StockNo.Trim());
        }

        private void Sign_btn_Click(object sender, EventArgs e)
        {
            if (Account_txt.Text == "" || Password_txt.Text == "")
            {
                Msg_lst.Items.Add("[帳號] [密碼] 不可空白");
                return;
            }
            else
            {
                //_Center.SKCenterLib_ResetServer("morder1.capital.com.tw");
                int _Signcode = _Center.SKCenterLib_Login(Account_txt.Text.Trim().ToUpper(),Password_txt.Text.Trim());
                if (_Signcode == 0)
                {

                    this.Get_ID = Account_txt.Text.Trim().ToUpper();

                    _Order.OnAccount += new _ISKOrderLibEvents_OnAccountEventHandler(Get_OnAccount);

                    //_Quote.OnConnection += new _ISKQuoteLibEvents_OnConnectionEventHandler(Con_OnConnetction);
                    _Quote.OnNotifyQuote += new _ISKQuoteLibEvents_OnNotifyQuoteEventHandler(Update_OnNotifyQuote);

                    int _OrderInit = _Order.SKOrderLib_Initialize();
                    int _OrderCert = _Order.ReadCertByID(this.Get_ID);
                    int _QuoteConn = _Quote.SKQuoteLib_EnterMonitor();

                    Account_pnl.Visible = false;
                    //Main_pnl.Height = 430;
                    //Main_pnl.Width = 1011;
                    Main_pnl.Visible = true;
                    //AccountPnl  340, 181

                    _Order.GetUserAccount();
                    //if (_OrderCert == 0) {
                    //    Account_pnl.Visible = false;
                    //    //Main_pnl.Height = 430;
                    //    //Main_pnl.Width = 1011;
                    //    Main_pnl.Visible = true;
                    //    //AccountPnl  340, 181
                    //    //1033 520 WINFORM
                    //    //340 180 Account_pnl Location
                    //    Msg_lst.Items.Add("讀取憑證　[完成]");
                    //    if (Remember_chk.Checked == true) {
                    //        Properties.Settings.Default.Account = Account_txt.Text.Trim().ToUpper();
                    //        Properties.Settings.Default.Rember_Chk = true;
                    //        Properties.Settings.Default.Save();
                    //    }
                    //    else {
                    //        Properties.Settings.Default.Account = "";
                    //        Properties.Settings.Default.Rember_Chk = false;
                    //        Properties.Settings.Default.Save();
                    //    }
                    //}
                    //else {
                    //    Msg_lst.Items.Add("讀取憑證　[失敗]");
                    //}
                }
                else
                {
                    _Log += 1;
                    Msg_lst.Items.Add("請再次確認[帳號][密碼]　" + "　登入失敗：　" + _Log + "　次");
                }
            }
        }

        private void AddNewData(string OrderMode,
                                string ID,
                                string Con,
                                string Pri,
                                string Method,
                                string OrderPri,
                                string Qty,
                                string Exe,
                                string StateOne,
                                string SpProfit,
                                string SpLoss,
                                string StateTwo) {
            string StockNo = "";

            DataRow Dr = UserAddTable.NewRow();
            Dr["種類"] = OrderMode;
            Dr["股票代號"] = ID;
            Dr["條件"] = Con;
            Dr["價格"] = Pri;
            Dr["方法"] = Method;
            Dr["掛單價格"] = OrderPri;
            Dr["數量(張)"] = Qty;
            Dr["執行"] = Exe;
            Dr["狀態(1)"] = StateOne;
            Dr["停利價格"] = SpProfit;
            Dr["停損價格"] = SpLoss;
            Dr["狀態(2)"] = StateTwo;
            UserAddTable.Rows.Add(Dr);

            for (int i = 0; i < StopLoss_dgv.RowCount; i++) {
                if (i == 0) {
                    StockNo = StopLoss_dgv.Rows[i].Cells[2].Value.ToString();
                }
                else {
                    StockNo = StockNo + "," + StopLoss_dgv.Rows[i].Cells[2].Value.ToString();
                }
            }
            RequestQuote(StockNo);
        }

        //void Con_OnConnetction(int nKind, int nCode)
        //{
        //    if (nKind == 3003)
        //    {

        //    }
        //}

        void Get_OnAccount(string bstrLogInID, string bstrAccountData)
        {
            string[] strValues;
            string strAccount;

            strValues = bstrAccountData.Split(',');
            strAccount = strValues[1] + strValues[3];

            if (strValues[0] == "TS")
                Order_Account = strAccount;
        }

        private void StopLoss_dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string StockNo = "";
            if (e.ColumnIndex == 0)
            {
                StopLoss_dgv.Rows.RemoveAt(e.RowIndex);
                //(sender as DataGridView).Rows.RemoveAt(e.RowIndex);
                for (int i = 0; i < StopLoss_dgv.RowCount; i++)
                {
                    if (i == 0)
                    {
                        StockNo = StopLoss_dgv.Rows[i].Cells[1].Value.ToString();
                    }
                    else
                    {
                        StockNo = StockNo + "," + StopLoss_dgv.Rows[i].Cells[1].Value.ToString();
                    }
                }
                RequestQuote(StockNo);
            }
        }

        void Update_OnNotifyQuote(short sMarketNo, short sStockIdx)
        {
            SKSTOCK QuoteStockStruct = new SKSTOCK();
            _Quote.SKQuoteLib_GetStockByIndex(sMarketNo, sStockIdx, ref QuoteStockStruct);
            OnUpDateDataRow(QuoteStockStruct);
        }

        private void OnUpDateDataRow(SKSTOCK QuoteStockStruct)
        {
            string strStockNo = QuoteStockStruct.bstrStockNo;

            DataRow drFind = StockQuoteTable.Rows.Find(strStockNo);
            if (drFind == null)
            {
                try
                {
                    DataRow myDataRow = StockQuoteTable.NewRow();

                    myDataRow["nStockNo"] = QuoteStockStruct.bstrStockNo;
                    myDataRow["nClose"] = QuoteStockStruct.nClose / (Math.Pow(10, QuoteStockStruct.sDecimal));

                    StockQuoteTable.Rows.Add(myDataRow);

                }
                catch (Exception ex)
                {
                }
            }
            else
            {
                drFind["nStockNo"] = QuoteStockStruct.bstrStockNo;
                drFind["nClose"] = QuoteStockStruct.nClose / (Math.Pow(10, QuoteStockStruct.sDecimal));
            }

            for (int i = 0; i < StockQuoteTable.Rows.Count; i++)
            {
                if (StopLoss_dgv.Rows[i].Cells[1].Value.ToString() == "觸價單 ( MIT )" && StopLoss_dgv.Rows[i].Cells[9].Value.ToString() == "已執行") {
                    return;
                }
                else if (StopLoss_dgv.Rows[i].Cells[1].Value.ToString() == "OCO ( One Cancel the Other )" && StopLoss_dgv.Rows[i].Cells[9].Value.ToString() == "已執行" && StopLoss_dgv.Rows[i].Cells[12].Value.ToString() == "已執行") {
                    return;
                }

                switch (StopLoss_dgv.Rows[i].Cells[1].Value.ToString()) {
                    case "觸價單 ( MIT )": {
                            switch (StopLoss_dgv.Rows[i].Cells[3].Value.ToString()) {
                                case "大於等於": {
                                        if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) != 0) {
                                            //if (((Convert.ToDouble(StockQuoteTable.Rows[i][1]) > Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value)) || (Convert.ToDouble(StockQuoteTable.Rows[i][1]) == Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value))) && StopLoss_dgv.Rows[i].Cells[8].Value.ToString() == "未執行")
                                            if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) >= Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[4].Value)) {
                                                if (StopLoss_dgv.Rows[i].Cells[7].Value.ToString() == "賣出") {
                                                    short BS = 1;
                                                    ThrowOrder( StopLoss_dgv.Rows[i].Cells[1].Value.ToString(),
                                                                StopLoss_dgv.Rows[i].Cells[4].Value.ToString(),
                                                                BS,
                                                                StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                                                                Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[6].Value));
                                                }
                                                else {
                                                    short BS = 0;
                                                    ThrowOrder( StopLoss_dgv.Rows[i].Cells[1].Value.ToString(),
                                                                StopLoss_dgv.Rows[i].Cells[4].Value.ToString(),
                                                                BS,
                                                                StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                                                                Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[6].Value));
                                                }
                                                StopLoss_dgv.Rows[i].Cells[8].Value = "已執行";
                                            }
                                        }
                                        break;
                                    }
                                case "小於等於": {
                                        if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) != 0) {
                                            //if (((Convert.ToDouble(StockQuoteTable.Rows[i][1]) < Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value)) || (Convert.ToDouble(StockQuoteTable.Rows[i][1]) == Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value))) && StopLoss_dgv.Rows[i].Cells[8].Value.ToString() == "未執行")
                                            if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) <= Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[4].Value)) {
                                                if (StopLoss_dgv.Rows[i].Cells[7].Value.ToString() == "賣出") {
                                                    short BS = 1;
                                                    ThrowOrder( StopLoss_dgv.Rows[i].Cells[2].Value.ToString(),
                                                                StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                                                                BS,
                                                                StopLoss_dgv.Rows[i].Cells[6].Value.ToString(),
                                                                Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[7].Value));
                                                }
                                                else {
                                                    short BS = 0;
                                                    ThrowOrder( StopLoss_dgv.Rows[i].Cells[1].Value.ToString(),
                                                                StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                                                                BS,
                                                                StopLoss_dgv.Rows[i].Cells[6].Value.ToString(),
                                                                Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[7].Value));
                                                }
                                                StopLoss_dgv.Rows[i].Cells[8].Value = "已執行";
                                            }
                                        }
                                        break;
                                    }
                            }
                            break;
                        }
                    case "OCO ( One Cancel the Other )": {
                            if (StopLoss_dgv.Rows[i].Cells[9].Value.ToString() == "未執行") {
                                switch (StopLoss_dgv.Rows[i].Cells[3].Value.ToString()) {
                                    case "大於等於": {
                                            if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) != 0) {
                                                //if (((Convert.ToDouble(StockQuoteTable.Rows[i][1]) > Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value)) || (Convert.ToDouble(StockQuoteTable.Rows[i][1]) == Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value))) && StopLoss_dgv.Rows[i].Cells[8].Value.ToString() == "未執行")
                                                if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) >= Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[4].Value) && StopLoss_dgv.Rows[i].Cells[9].Value.ToString() == "未執行") {
                                                    if (StopLoss_dgv.Rows[i].Cells[7].Value.ToString() == "賣出") {
                                                        short BS = 1;
                                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[1].Value.ToString(),
                                                                    StopLoss_dgv.Rows[i].Cells[4].Value.ToString(),
                                                                    BS,
                                                                    StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                                                                    Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[6].Value));
                                                    }
                                                    else {
                                                        short BS = 0;
                                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[1].Value.ToString(),
                                                                    StopLoss_dgv.Rows[i].Cells[4].Value.ToString(),
                                                                    BS,
                                                                    StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                                                                    Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[6].Value));
                                                    }
                                                    StopLoss_dgv.Rows[i].Cells[9].Value = "已執行";
                                                }
                                            }
                                            break;
                                        }
                                    case "小於等於": {
                                            if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) != 0) {
                                                //if (((Convert.ToDouble(StockQuoteTable.Rows[i][1]) < Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value)) || (Convert.ToDouble(StockQuoteTable.Rows[i][1]) == Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[3].Value))) && StopLoss_dgv.Rows[i].Cells[8].Value.ToString() == "未執行")
                                                if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) <= Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[4].Value) && StopLoss_dgv.Rows[i].Cells[9].Value.ToString() == "未執行") {
                                                    if (StopLoss_dgv.Rows[i].Cells[7].Value.ToString() == "賣出") {
                                                        short BS = 1;
                                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[2].Value.ToString(),
                                                                    StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                                                                    BS,
                                                                    StopLoss_dgv.Rows[i].Cells[6].Value.ToString(),
                                                                    Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[7].Value));
                                                    }
                                                    else {
                                                        short BS = 0;
                                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[1].Value.ToString(),
                                                                    StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                                                                    BS,
                                                                    StopLoss_dgv.Rows[i].Cells[6].Value.ToString(),
                                                                    Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[7].Value));
                                                    }
                                                    StopLoss_dgv.Rows[i].Cells[9].Value = "已執行";
                                                }
                                            }
                                            break;
                                        }
                                }
                            }
                            else if (StopLoss_dgv.Rows[i].Cells[9].Value.ToString() == "已執行" && StopLoss_dgv.Rows[i].Cells[12].Value.ToString() == "未執行") {
                                if (StopLoss_dgv.Rows[i].Cells[5].Value.ToString() == "買進") {
                                    if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) >= Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[10].Value)) {
                                        short BS = 1;
                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[2].Value.ToString(),
                                                    StopLoss_dgv.Rows[i].Cells[6].Value.ToString(),
                                                    BS,
                                                    StopLoss_dgv.Rows[i].Cells[10].Value.ToString(),
                                                    Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[7].Value));
                                    }
                                    else if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) <= Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[11].Value)) {
                                        short BS = 1;
                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[2].Value.ToString(),
                                                    StopLoss_dgv.Rows[i].Cells[6].Value.ToString(),
                                                    BS,
                                                    StopLoss_dgv.Rows[i].Cells[11].Value.ToString(),
                                                    Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[7].Value));
                                    }
                                    StopLoss_dgv.Rows[i].Cells[12].Value = "已執行";
                                }
                                else if (StopLoss_dgv.Rows[i].Cells[5].Value.ToString() == "賣出") {
                                    if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) <= Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[10].Value)) {
                                        short BS = 0;
                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[2].Value.ToString(),
                                                    StopLoss_dgv.Rows[i].Cells[6].Value.ToString(),
                                                    BS,
                                                    StopLoss_dgv.Rows[i].Cells[10].Value.ToString(),
                                                    Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[7].Value));
                                    }
                                    else if (Convert.ToDouble(StockQuoteTable.Rows[i][1]) >= Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[11].Value)) {
                                        short BS = 0;
                                        ThrowOrder(StopLoss_dgv.Rows[i].Cells[2].Value.ToString(),
                                                    StopLoss_dgv.Rows[i].Cells[6].Value.ToString(),
                                                    BS,
                                                    StopLoss_dgv.Rows[i].Cells[11].Value.ToString(),
                                                    Convert.ToInt16(StopLoss_dgv.Rows[i].Cells[7].Value));
                                    }
                                    StopLoss_dgv.Rows[i].Cells[12].Value = "已執行";
                                }
                            }
                            break;
                        }
                }
            }
        }

        private void ThrowOrder(string StockID, string OrderMethod, short BS, string Price, int Qty)
        {
            string strMsg = "";
            short OrderMethod_code = 0;

            switch (OrderMethod)
            {
                case "現股":
                    {
                        OrderMethod_code = 0;
                        break;
                    }
                case "融資":
                    {
                        OrderMethod_code = 1;
                        break;
                    }
                case "融券":
                    {
                        OrderMethod_code = 2;
                        break;
                    }
            }

            STOCKORDER S_Order = new STOCKORDER();
            S_Order.bstrFullAccount = Order_Account;
            S_Order.bstrStockNo = StockID;
            S_Order.sPrime = 0;
            S_Order.sPeriod = 0;

            S_Order.sFlag = OrderMethod_code;
            S_Order.sBuySell = BS;
            S_Order.bstrPrice = Price;
            S_Order.nQty = Qty;

            int Order_code = _Order.SendStockOrder(Account_ID, true, S_Order, out strMsg);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Account_txt.Text = Properties.Settings.Default.Account;
            Remember_chk.Checked = Properties.Settings.Default.Rember_Chk;
        }

        private void Password_txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keys.Enter != e.KeyCode) return;
            Sign_btn_Click(sender, e);
        }

        private void Account_txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keys.Enter != e.KeyCode) return;
            Password_txt.Focus();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!(StopLoss_dgv.Rows.Count > 0)) {
                return;
            }

            UserSetting US = new UserSetting();
            XmlTextWriter XTW = US.CreatXmlFile();
            for (int i = 0; i < StopLoss_dgv.Rows.Count; i++)
            {
                US.IntoData(StopLoss_dgv.Rows[i].Cells[1].Value.ToString(),
                            StopLoss_dgv.Rows[i].Cells[2].Value.ToString(),
                            StopLoss_dgv.Rows[i].Cells[3].Value.ToString(),
                            Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[4].Value.ToString()),
                            StopLoss_dgv.Rows[i].Cells[5].Value.ToString(),
                            Convert.ToDouble(StopLoss_dgv.Rows[i].Cells[6].Value.ToString()),
                            StopLoss_dgv.Rows[i].Cells[7].Value.ToString(),
                            StopLoss_dgv.Rows[i].Cells[8].Value.ToString(),
                            StopLoss_dgv.Rows[i].Cells[9].Value.ToString(),
                            StopLoss_dgv.Rows[i].Cells[10].Value.ToString(),
                            StopLoss_dgv.Rows[i].Cells[11].Value.ToString(),
                            StopLoss_dgv.Rows[i].Cells[12].Value.ToString(),
                            XTW);
            }
            XTW.WriteEndElement();
            XTW.Close();
        }

        private void History_Click(object sender, EventArgs e)
        {
            DirectoryInfo F = new DirectoryInfo("C:\\buildUSERset");
            foreach (var Df in F.GetFiles()) {
                if (Df.ToString() != "USERSet_V02.xml") {
                    File.Delete("C:\\buildUSERset\\" + Df.ToString());
                }
            }

            if (File.Exists("C:\\buildUSERset\\USERSet_V02.xml"))
            {
                XmlDataDocument XmlDoc = new XmlDataDocument();
                XmlNodeList XmlNode;

                FileStream Fs = new FileStream("C:\\buildUSERset\\USERSet_V02.xml", FileMode.Open, FileAccess.Read);
                XmlDoc.Load(Fs);

                XmlNode = XmlDoc.GetElementsByTagName("New_Item");
                for (int i = 0; i <= XmlNode.Count - 1; i++)
                {
                    AddNewData(XmlNode[i].ChildNodes.Item(0).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(1).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(2).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(3).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(4).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(5).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(6).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(7).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(8).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(9).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(10).InnerText.Trim().ToString(),
                                XmlNode[i].ChildNodes.Item(11).InnerText.Trim().ToString());
                }
                Fs.Close();
            }
            History.Enabled = false;
        }

        private void MIT_Radio_CheckedChanged(object sender, EventArgs e)
        {
            if (!MIT_Radio.Checked) {
                OCO_Grpbx.Visible = true;
            }
            else
            {
                OCO_Grpbx.Visible = false;
            }

        }

        private void button1_Click(object sender, EventArgs e) {
            MessageBox.Show(StockQuoteTable.Rows[0][1].ToString());
        }
    }
}