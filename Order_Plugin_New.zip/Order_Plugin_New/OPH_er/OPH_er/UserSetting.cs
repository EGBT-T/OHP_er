﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace OPH_er
{
    class UserSetting
    {
        private string DirPath = "C:\\buildUSERset\\";
        private string XMLPath = "C:\\buildUSERset\\USERSet.xml";

        public XmlTextWriter CreatXmlFile() {
            Directory.CreateDirectory(DirPath);
            XmlTextWriter SetXML = new XmlTextWriter(DirPath + "USERset.xml", Encoding.UTF8);
            SetXML.WriteStartElement("Stock_Item");
            SetXML.Formatting = Formatting.Indented;
            SetXML.Indentation = 2;
            return SetXML;
        }

        public void LoadXmlFile() {
            Form1 Fm = new Form1();
            Fm.wri("1", "2", "3", "4", "5", "6", "7", "8");
            //if (File.Exists("C:\\buildUSERset\\SET.xml")) {
            //    Form1 Fm = new Form1();
            //    XmlDataDocument XmlDoc = new XmlDataDocument();
            //    XmlNodeList XmlNode;

            //    FileStream Fs = new FileStream("C:\\buildUSERset\\SET.xml", FileMode.Open, FileAccess.Read);
            //    XmlDoc.Load(Fs);
            //    XmlNode = XmlDoc.GetElementsByTagName("Stock_Item");
            //    for (int i = 0; i <= XmlNode.Count - 1; i++) {
            //        DataRow Dr = Fm.UserAddTable.NewRow();
            //        Dr["股票代號"] = XmlNode[i].ChildNodes.Item(0).InnerText.Trim().ToString();
            //        Dr["條件"] = XmlNode[i].ChildNodes.Item(1).InnerText.Trim().ToString();
            //        Dr["價格"] = Convert.ToDouble(XmlNode[i].ChildNodes.Item(2).InnerText.Trim());
            //        Dr["方法"] = XmlNode[i].ChildNodes.Item(3).InnerText.Trim().ToString();
            //        Dr["掛單價格"] = Convert.ToDouble(XmlNode[i].ChildNodes.Item(4).InnerText.Trim());
            //        Dr["數量(張)"] = XmlNode[i].ChildNodes.Item(5).InnerText.Trim().ToString();
            //        Dr["執行"] = XmlNode[i].ChildNodes.Item(6).InnerText.Trim().ToString();
            //        Dr["狀態"] = XmlNode[i].ChildNodes.Item(7).InnerText.Trim().ToString();
            //        Fm.UserAddTable.Rows.Add(Dr);
            //    }
            //}
        }

        public void IntoData(string StockID,
                            string StockCon,
                            string StockPri,
                            string OrderMethod,
                            string StockOrderPri,
                            string StockQty,
                            string Exe,
                            string State,
                            XmlTextWriter FileName) {
            FileName.WriteStartElement("New_Item", null);
            FileName.WriteStartElement("ID", null);
            FileName.WriteString(StockID);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Con", null);
            FileName.WriteString(StockCon);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Pri", null);
            FileName.WriteString(StockPri);
            FileName.WriteEndElement();
            FileName.WriteStartElement("OrderMethod", null);
            FileName.WriteString(OrderMethod);
            FileName.WriteEndElement();
            FileName.WriteStartElement("OrderPri", null);
            FileName.WriteString(StockOrderPri);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Qty", null);
            FileName.WriteString(StockQty);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Exe", null);
            FileName.WriteString(Exe);
            FileName.WriteEndElement();
            FileName.WriteStartElement("State", null);
            FileName.WriteString(State);
            FileName.WriteEndElement();
            FileName.WriteEndElement();
        }
    }
}
