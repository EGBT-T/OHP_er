﻿using System.IO;
using System.Text;
using System.Xml;

namespace OPH_er
{
    class UserSetting
    {
        private string DirPath = "C:\\buildUSERset\\";
        private string XMLPath = "C:\\buildUSERset\\USERSet_V02.xml";

        public XmlTextWriter CreatXmlFile() {
            Directory.CreateDirectory(DirPath);
            XmlTextWriter SetXML = new XmlTextWriter(XMLPath, Encoding.UTF8);
            SetXML.WriteStartDocument(true);
            SetXML.Formatting = Formatting.Indented;
            SetXML.Indentation = 2;
            SetXML.WriteStartElement("Stock_Item");
            return SetXML;
        }

        public void IntoData(string Mode,
                            string StockID,
                            string StockCon,
                            double StockPri,
                            string OrderMethod,
                            double StockOrderPri,
                            string StockQty,
                            string Exe,
                            string StateO,
                            string SpProfit,
                            string SpLoss,
                            string StateT,
                            XmlTextWriter FileName) {
            FileName.WriteStartElement("New_Item", null);
            FileName.WriteStartElement("Mode", null);
            FileName.WriteString(Mode);
            FileName.WriteEndElement();
            FileName.WriteStartElement("ID", null);
            FileName.WriteString(StockID);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Con", null);
            FileName.WriteString(StockCon);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Pri", null);
            FileName.WriteValue(StockPri);
            FileName.WriteEndElement();
            FileName.WriteStartElement("OrderMethod", null);
            FileName.WriteString(OrderMethod);
            FileName.WriteEndElement();
            FileName.WriteStartElement("OrderPri", null);
            FileName.WriteValue(StockOrderPri);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Qty", null);
            FileName.WriteString(StockQty);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Exe", null);
            FileName.WriteString(Exe);
            FileName.WriteEndElement();
            FileName.WriteStartElement("State", null);
            FileName.WriteString(StateO);
            FileName.WriteEndElement();
            FileName.WriteStartElement("SpProfit", null);
            FileName.WriteString(SpProfit);
            FileName.WriteEndElement();
            FileName.WriteStartElement("SpLoss", null);
            FileName.WriteString(SpLoss);
            FileName.WriteEndElement();
            FileName.WriteStartElement("StateT", null);
            FileName.WriteString(StateT);
            FileName.WriteEndElement();
            FileName.WriteEndElement();
        }
    }
}