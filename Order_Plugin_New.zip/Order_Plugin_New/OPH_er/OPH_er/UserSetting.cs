﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace OPH_er
{
    class UserSetting
    {
        private string Dir = @"C:\buildUSERset\";
        private XmlTextWriter SetXML;

        public XmlTextWriter CreatXmlFile() {
            if (!File.Exists(Dir + "USERset.xml")) {
                SetXML = new XmlTextWriter (Dir + "USERset.xml", Encoding.UTF8);
                SetXML.Formatting = 
            }
            return SetXML;
        }

        public void IntoData(string StockID,
                            string StockCon,
                            string StockPri,
                            string StockOrderPri,
                            string StockQty,
                            string Exe,
                            string State,
                            XmlTextWriter FileName) {
            FileName.WriteStartElement("ID", null);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Con", null);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Pri", null);
            FileName.WriteEndElement();
            FileName.WriteStartElement("OrderPri", null);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Qty", null);
            FileName.WriteEndElement();
            FileName.WriteStartElement("Exe", null);
            FileName.WriteEndElement();
            FileName.WriteStartElement("State", null);
            FileName.WriteString(State);
            FileName.WriteEndElement();
        }
    }
}
