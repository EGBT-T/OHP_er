﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace OPH_er
{
    class UserSettingClass
    {
        private string Dirpath = @"C:\buildUSERset\";
        private string Filename = "SET.xml";

        public void CreateXml()
        {
            string path = @"C:\buildUSERset\test.xml";
            XmlTextWriter writer = new XmlTextWriter(path, null);
            writer.Close();
        }

        public void IntoData(string StockID,
                            string Con,
                            string Pri,
                            string Method,
                            string OrderPri,
                            string Qty,
                            string Exe,
                            string State,
                            XmlTextWriter XTW) {
            XTW.WriteStartElement("Stock_Item");
            XTW.WriteStartElement("Stock_ID");
            XTW.WriteString(StockID);
            XTW.WriteEndElement();
            XTW.WriteStartElement("Stock_Condition");
            XTW.WriteString(Con);
            XTW.WriteEndElement();
            XTW.WriteStartElement("Stock_Pri");
            XTW.WriteString(Pri);
            XTW.WriteEndElement();
            XTW.WriteStartElement("Stock_Method");
            XTW.WriteString(Method);
            XTW.WriteEndElement();
            XTW.WriteStartElement("Stock_OrderPri");
            XTW.WriteString(OrderPri);
            XTW.WriteEndElement();
            XTW.WriteStartElement("Stock_Qty");
            XTW.WriteString(Qty);
            XTW.WriteEndElement();
            XTW.WriteStartElement("Stock_Exe");
            XTW.WriteString(Exe);
            XTW.WriteEndElement();
            XTW.WriteStartElement("Stock_State");
            XTW.WriteString(State);
            XTW.WriteEndElement();
            XTW.WriteEndElement();
        }
    }
}
