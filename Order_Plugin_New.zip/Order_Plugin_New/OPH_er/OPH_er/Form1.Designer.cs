﻿namespace OPH_er
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Main_pnl = new System.Windows.Forms.Panel();
            this.StopLoss_dgv = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.OrderPrice_txt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.StockExe_cmbbx = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Add_btn = new System.Windows.Forms.Button();
            this.StockQty_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Conditionprice_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Stockcondition_cmbbx = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Stockcode_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Msg_lst = new System.Windows.Forms.ListBox();
            this.Account_pnl = new System.Windows.Forms.Panel();
            this.Remember_chk = new System.Windows.Forms.CheckBox();
            this.Sign_btn = new System.Windows.Forms.Button();
            this.Password_txt = new System.Windows.Forms.TextBox();
            this.Account_txt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.OrderMethod_cmbbx = new System.Windows.Forms.ComboBox();
            this.Del = new System.Windows.Forms.DataGridViewButtonColumn();
            this.StockID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Condition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Condition_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderMethod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Order_price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quatity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Exe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Main_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StopLoss_dgv)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.Account_pnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // Main_pnl
            // 
            this.Main_pnl.Controls.Add(this.StopLoss_dgv);
            this.Main_pnl.Controls.Add(this.groupBox1);
            this.Main_pnl.Location = new System.Drawing.Point(0, 0);
            this.Main_pnl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Main_pnl.Name = "Main_pnl";
            this.Main_pnl.Size = new System.Drawing.Size(0, 0);
            this.Main_pnl.TabIndex = 0;
            this.Main_pnl.Visible = false;
            // 
            // StopLoss_dgv
            // 
            this.StopLoss_dgv.AllowUserToAddRows = false;
            this.StopLoss_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StopLoss_dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Del,
            this.StockID,
            this.Condition,
            this.Condition_Price,
            this.OrderMethod,
            this.Order_price,
            this.Quatity,
            this.Exe,
            this.State});
            this.StopLoss_dgv.Location = new System.Drawing.Point(16, 115);
            this.StopLoss_dgv.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.StopLoss_dgv.Name = "StopLoss_dgv";
            this.StopLoss_dgv.ReadOnly = true;
            this.StopLoss_dgv.RowTemplate.Height = 24;
            this.StopLoss_dgv.Size = new System.Drawing.Size(1332, 238);
            this.StopLoss_dgv.TabIndex = 11;
            this.StopLoss_dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StopLoss_dgv_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.OrderMethod_cmbbx);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.OrderPrice_txt);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.StockExe_cmbbx);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.Add_btn);
            this.groupBox1.Controls.Add(this.StockQty_txt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Conditionprice_txt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Stockcondition_cmbbx);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Stockcode_txt);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(16, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(1332, 92);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "停損單設定";
            // 
            // OrderPrice_txt
            // 
            this.OrderPrice_txt.Location = new System.Drawing.Point(622, 50);
            this.OrderPrice_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.OrderPrice_txt.Name = "OrderPrice_txt";
            this.OrderPrice_txt.Size = new System.Drawing.Size(105, 25);
            this.OrderPrice_txt.TabIndex = 5;
            this.OrderPrice_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 15F);
            this.label8.Location = new System.Drawing.Point(477, 50);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 25);
            this.label8.TabIndex = 14;
            this.label8.Text = "掛單價格：";
            // 
            // StockExe_cmbbx
            // 
            this.StockExe_cmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StockExe_cmbbx.FormattingEnabled = true;
            this.StockExe_cmbbx.Items.AddRange(new object[] {
            "買進",
            "賣出"});
            this.StockExe_cmbbx.Location = new System.Drawing.Point(1051, 38);
            this.StockExe_cmbbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.StockExe_cmbbx.Name = "StockExe_cmbbx";
            this.StockExe_cmbbx.Size = new System.Drawing.Size(105, 23);
            this.StockExe_cmbbx.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 15F);
            this.label5.Location = new System.Drawing.Point(951, 38);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "執行：";
            // 
            // Add_btn
            // 
            this.Add_btn.Font = new System.Drawing.Font("新細明體", 15F);
            this.Add_btn.Location = new System.Drawing.Point(1165, 18);
            this.Add_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Add_btn.Name = "Add_btn";
            this.Add_btn.Size = new System.Drawing.Size(153, 65);
            this.Add_btn.TabIndex = 8;
            this.Add_btn.Text = "新增";
            this.Add_btn.UseVisualStyleBackColor = true;
            this.Add_btn.Click += new System.EventHandler(this.Add_btn_Click);
            // 
            // StockQty_txt
            // 
            this.StockQty_txt.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.StockQty_txt.Location = new System.Drawing.Point(889, 38);
            this.StockQty_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.StockQty_txt.Name = "StockQty_txt";
            this.StockQty_txt.Size = new System.Drawing.Size(52, 25);
            this.StockQty_txt.TabIndex = 6;
            this.StockQty_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 15F);
            this.label4.Location = new System.Drawing.Point(747, 38);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "數量(張)：";
            // 
            // Conditionprice_txt
            // 
            this.Conditionprice_txt.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Conditionprice_txt.Location = new System.Drawing.Point(364, 50);
            this.Conditionprice_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Conditionprice_txt.Name = "Conditionprice_txt";
            this.Conditionprice_txt.Size = new System.Drawing.Size(105, 25);
            this.Conditionprice_txt.TabIndex = 3;
            this.Conditionprice_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 15F);
            this.label3.Location = new System.Drawing.Point(264, 50);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "價格：";
            // 
            // Stockcondition_cmbbx
            // 
            this.Stockcondition_cmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Stockcondition_cmbbx.FormattingEnabled = true;
            this.Stockcondition_cmbbx.IntegralHeight = false;
            this.Stockcondition_cmbbx.ItemHeight = 15;
            this.Stockcondition_cmbbx.Items.AddRange(new object[] {
            "大於等於",
            "小於等於"});
            this.Stockcondition_cmbbx.Location = new System.Drawing.Point(364, 18);
            this.Stockcondition_cmbbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Stockcondition_cmbbx.Name = "Stockcondition_cmbbx";
            this.Stockcondition_cmbbx.Size = new System.Drawing.Size(105, 23);
            this.Stockcondition_cmbbx.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 15F);
            this.label2.Location = new System.Drawing.Point(264, 18);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "條件：";
            // 
            // Stockcode_txt
            // 
            this.Stockcode_txt.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Stockcode_txt.Location = new System.Drawing.Point(149, 38);
            this.Stockcode_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Stockcode_txt.Name = "Stockcode_txt";
            this.Stockcode_txt.Size = new System.Drawing.Size(105, 25);
            this.Stockcode_txt.TabIndex = 1;
            this.Stockcode_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Stockcode_txt.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 15F);
            this.label1.Location = new System.Drawing.Point(8, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "股票代號：";
            // 
            // Msg_lst
            // 
            this.Msg_lst.FormattingEnabled = true;
            this.Msg_lst.ItemHeight = 15;
            this.Msg_lst.Location = new System.Drawing.Point(15, 364);
            this.Msg_lst.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Msg_lst.Name = "Msg_lst";
            this.Msg_lst.Size = new System.Drawing.Size(1331, 229);
            this.Msg_lst.TabIndex = 13;
            // 
            // Account_pnl
            // 
            this.Account_pnl.Controls.Add(this.Remember_chk);
            this.Account_pnl.Controls.Add(this.Sign_btn);
            this.Account_pnl.Controls.Add(this.Password_txt);
            this.Account_pnl.Controls.Add(this.Account_txt);
            this.Account_pnl.Controls.Add(this.label7);
            this.Account_pnl.Controls.Add(this.label6);
            this.Account_pnl.Location = new System.Drawing.Point(453, 226);
            this.Account_pnl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Account_pnl.Name = "Account_pnl";
            this.Account_pnl.Size = new System.Drawing.Size(452, 132);
            this.Account_pnl.TabIndex = 1;
            // 
            // Remember_chk
            // 
            this.Remember_chk.AutoSize = true;
            this.Remember_chk.Font = new System.Drawing.Font("新細明體", 15F);
            this.Remember_chk.Location = new System.Drawing.Point(104, 101);
            this.Remember_chk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Remember_chk.Name = "Remember_chk";
            this.Remember_chk.Size = new System.Drawing.Size(134, 29);
            this.Remember_chk.TabIndex = 5;
            this.Remember_chk.Text = "記住帳號";
            this.Remember_chk.UseVisualStyleBackColor = true;
            // 
            // Sign_btn
            // 
            this.Sign_btn.Font = new System.Drawing.Font("新細明體", 15F);
            this.Sign_btn.Location = new System.Drawing.Point(347, 5);
            this.Sign_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sign_btn.Name = "Sign_btn";
            this.Sign_btn.Size = new System.Drawing.Size(100, 89);
            this.Sign_btn.TabIndex = 3;
            this.Sign_btn.Text = "登入";
            this.Sign_btn.UseVisualStyleBackColor = true;
            this.Sign_btn.Click += new System.EventHandler(this.Sign_btn_Click);
            // 
            // Password_txt
            // 
            this.Password_txt.Location = new System.Drawing.Point(104, 66);
            this.Password_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Password_txt.Name = "Password_txt";
            this.Password_txt.PasswordChar = '●';
            this.Password_txt.Size = new System.Drawing.Size(233, 25);
            this.Password_txt.TabIndex = 2;
            this.Password_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Account_txt
            // 
            this.Account_txt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Account_txt.Font = new System.Drawing.Font("新細明體", 12F);
            this.Account_txt.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Account_txt.Location = new System.Drawing.Point(104, 5);
            this.Account_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Account_txt.Name = "Account_txt";
            this.Account_txt.Size = new System.Drawing.Size(233, 31);
            this.Account_txt.TabIndex = 1;
            this.Account_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 15F);
            this.label7.Location = new System.Drawing.Point(4, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 25);
            this.label7.TabIndex = 1;
            this.label7.Text = "密碼：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 15F);
            this.label6.Location = new System.Drawing.Point(4, 4);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "帳號：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("新細明體", 15F);
            this.label9.Location = new System.Drawing.Point(477, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 25);
            this.label9.TabIndex = 15;
            this.label9.Text = "方法：";
            // 
            // OrderMethod_cmbbx
            // 
            this.OrderMethod_cmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OrderMethod_cmbbx.FormattingEnabled = true;
            this.OrderMethod_cmbbx.Items.AddRange(new object[] {
            "現股",
            "融資",
            "融券"});
            this.OrderMethod_cmbbx.Location = new System.Drawing.Point(622, 19);
            this.OrderMethod_cmbbx.Name = "OrderMethod_cmbbx";
            this.OrderMethod_cmbbx.Size = new System.Drawing.Size(105, 23);
            this.OrderMethod_cmbbx.TabIndex = 4;
            // 
            // Del
            // 
            this.Del.HeaderText = "刪除";
            this.Del.Name = "Del";
            this.Del.ReadOnly = true;
            this.Del.Text = "刪除";
            this.Del.UseColumnTextForButtonValue = true;
            // 
            // StockID
            // 
            this.StockID.DataPropertyName = "股票代號";
            this.StockID.HeaderText = "股票代號";
            this.StockID.Name = "StockID";
            this.StockID.ReadOnly = true;
            // 
            // Condition
            // 
            this.Condition.DataPropertyName = "條件";
            this.Condition.HeaderText = "條件";
            this.Condition.Name = "Condition";
            this.Condition.ReadOnly = true;
            // 
            // Condition_Price
            // 
            this.Condition_Price.DataPropertyName = "價格";
            this.Condition_Price.HeaderText = "價格";
            this.Condition_Price.Name = "Condition_Price";
            this.Condition_Price.ReadOnly = true;
            // 
            // OrderMethod
            // 
            this.OrderMethod.DataPropertyName = "方法";
            this.OrderMethod.HeaderText = "方法";
            this.OrderMethod.Name = "OrderMethod";
            this.OrderMethod.ReadOnly = true;
            // 
            // Order_price
            // 
            this.Order_price.DataPropertyName = "掛單價格";
            this.Order_price.HeaderText = "掛單價格";
            this.Order_price.Name = "Order_price";
            this.Order_price.ReadOnly = true;
            // 
            // Quatity
            // 
            this.Quatity.DataPropertyName = "數量(張)";
            this.Quatity.HeaderText = "數量(張)";
            this.Quatity.Name = "Quatity";
            this.Quatity.ReadOnly = true;
            // 
            // Exe
            // 
            this.Exe.DataPropertyName = "執行";
            this.Exe.HeaderText = "執行";
            this.Exe.Name = "Exe";
            this.Exe.ReadOnly = true;
            // 
            // State
            // 
            this.State.DataPropertyName = "狀態";
            this.State.HeaderText = "狀態";
            this.State.Name = "State";
            this.State.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1356, 601);
            this.Controls.Add(this.Msg_lst);
            this.Controls.Add(this.Account_pnl);
            this.Controls.Add(this.Main_pnl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OPH_er";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Main_pnl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.StopLoss_dgv)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Account_pnl.ResumeLayout(false);
            this.Account_pnl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Main_pnl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox StockQty_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Conditionprice_txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Stockcondition_cmbbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Stockcode_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox StockExe_cmbbx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Add_btn;
        private System.Windows.Forms.DataGridView StopLoss_dgv;
        private System.Windows.Forms.Panel Account_pnl;
        private System.Windows.Forms.CheckBox Remember_chk;
        private System.Windows.Forms.Button Sign_btn;
        private System.Windows.Forms.TextBox Password_txt;
        private System.Windows.Forms.TextBox Account_txt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox Msg_lst;
        private System.Windows.Forms.TextBox OrderPrice_txt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox OrderMethod_cmbbx;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridViewButtonColumn Del;
        private System.Windows.Forms.DataGridViewTextBoxColumn StockID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Condition;
        private System.Windows.Forms.DataGridViewTextBoxColumn Condition_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderMethod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Order_price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quatity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Exe;
        private System.Windows.Forms.DataGridViewTextBoxColumn State;
    }
}

