﻿namespace OPH_er
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Main_pnl = new System.Windows.Forms.Panel();
            this.StopLoss_dgv = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.StockExe_cmbbx = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Add_btn = new System.Windows.Forms.Button();
            this.StockQty_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Stockprice_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Stockcondition_cmbbx = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Stockcode_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.Sign_btn = new System.Windows.Forms.Button();
            this.Password_txt = new System.Windows.Forms.TextBox();
            this.Account_txt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Del = new System.Windows.Forms.DataGridViewButtonColumn();
            this.StockID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Condition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quatity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Exe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Main_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StopLoss_dgv)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Main_pnl
            // 
            this.Main_pnl.Controls.Add(this.textBox1);
            this.Main_pnl.Controls.Add(this.listBox1);
            this.Main_pnl.Controls.Add(this.button1);
            this.Main_pnl.Controls.Add(this.StopLoss_dgv);
            this.Main_pnl.Controls.Add(this.groupBox1);
            this.Main_pnl.Location = new System.Drawing.Point(0, 0);
            this.Main_pnl.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Main_pnl.Name = "Main_pnl";
            this.Main_pnl.Size = new System.Drawing.Size(1532, 862);
            this.Main_pnl.TabIndex = 0;
            // 
            // StopLoss_dgv
            // 
            this.StopLoss_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StopLoss_dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Del,
            this.StockID,
            this.Condition,
            this.Price,
            this.Quatity,
            this.Exe});
            this.StopLoss_dgv.Location = new System.Drawing.Point(16, 115);
            this.StopLoss_dgv.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.StopLoss_dgv.Name = "StopLoss_dgv";
            this.StopLoss_dgv.RowTemplate.Height = 24;
            this.StopLoss_dgv.Size = new System.Drawing.Size(1332, 188);
            this.StopLoss_dgv.TabIndex = 11;
            this.StopLoss_dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StopLoss_dgv_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.StockExe_cmbbx);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.Add_btn);
            this.groupBox1.Controls.Add(this.StockQty_txt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Stockprice_txt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Stockcondition_cmbbx);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Stockcode_txt);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(16, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(1332, 92);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "停損單設定";
            // 
            // StockExe_cmbbx
            // 
            this.StockExe_cmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StockExe_cmbbx.FormattingEnabled = true;
            this.StockExe_cmbbx.Items.AddRange(new object[] {
            "買進",
            "賣出"});
            this.StockExe_cmbbx.Location = new System.Drawing.Point(1051, 38);
            this.StockExe_cmbbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.StockExe_cmbbx.Name = "StockExe_cmbbx";
            this.StockExe_cmbbx.Size = new System.Drawing.Size(105, 23);
            this.StockExe_cmbbx.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 15F);
            this.label5.Location = new System.Drawing.Point(951, 38);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "執行：";
            // 
            // Add_btn
            // 
            this.Add_btn.Font = new System.Drawing.Font("新細明體", 15F);
            this.Add_btn.Location = new System.Drawing.Point(1165, 18);
            this.Add_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Add_btn.Name = "Add_btn";
            this.Add_btn.Size = new System.Drawing.Size(153, 65);
            this.Add_btn.TabIndex = 8;
            this.Add_btn.Text = "新增";
            this.Add_btn.UseVisualStyleBackColor = true;
            this.Add_btn.Click += new System.EventHandler(this.Add_btn_Click);
            // 
            // StockQty_txt
            // 
            this.StockQty_txt.Location = new System.Drawing.Point(836, 38);
            this.StockQty_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.StockQty_txt.Multiline = true;
            this.StockQty_txt.Name = "StockQty_txt";
            this.StockQty_txt.Size = new System.Drawing.Size(105, 26);
            this.StockQty_txt.TabIndex = 7;
            this.StockQty_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 15F);
            this.label4.Location = new System.Drawing.Point(693, 38);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "數量(張)：";
            // 
            // Stockprice_txt
            // 
            this.Stockprice_txt.Location = new System.Drawing.Point(579, 38);
            this.Stockprice_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Stockprice_txt.Multiline = true;
            this.Stockprice_txt.Name = "Stockprice_txt";
            this.Stockprice_txt.Size = new System.Drawing.Size(105, 26);
            this.Stockprice_txt.TabIndex = 5;
            this.Stockprice_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 15F);
            this.label3.Location = new System.Drawing.Point(479, 38);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "價格：";
            // 
            // Stockcondition_cmbbx
            // 
            this.Stockcondition_cmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Stockcondition_cmbbx.FormattingEnabled = true;
            this.Stockcondition_cmbbx.IntegralHeight = false;
            this.Stockcondition_cmbbx.ItemHeight = 15;
            this.Stockcondition_cmbbx.Items.AddRange(new object[] {
            "大於等於",
            "小於等於"});
            this.Stockcondition_cmbbx.Location = new System.Drawing.Point(364, 38);
            this.Stockcondition_cmbbx.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Stockcondition_cmbbx.Name = "Stockcondition_cmbbx";
            this.Stockcondition_cmbbx.Size = new System.Drawing.Size(105, 23);
            this.Stockcondition_cmbbx.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 15F);
            this.label2.Location = new System.Drawing.Point(264, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "條件：";
            // 
            // Stockcode_txt
            // 
            this.Stockcode_txt.Location = new System.Drawing.Point(149, 38);
            this.Stockcode_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Stockcode_txt.Multiline = true;
            this.Stockcode_txt.Name = "Stockcode_txt";
            this.Stockcode_txt.Size = new System.Drawing.Size(105, 28);
            this.Stockcode_txt.TabIndex = 1;
            this.Stockcode_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 15F);
            this.label1.Location = new System.Drawing.Point(8, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "股票代號：";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.Sign_btn);
            this.panel1.Controls.Add(this.Password_txt);
            this.panel1.Controls.Add(this.Account_txt);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(1600, 52);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(452, 132);
            this.panel1.TabIndex = 1;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("新細明體", 15F);
            this.checkBox1.Location = new System.Drawing.Point(104, 101);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(134, 29);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "記住帳號";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Sign_btn
            // 
            this.Sign_btn.Font = new System.Drawing.Font("新細明體", 15F);
            this.Sign_btn.Location = new System.Drawing.Point(347, 5);
            this.Sign_btn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Sign_btn.Name = "Sign_btn";
            this.Sign_btn.Size = new System.Drawing.Size(100, 89);
            this.Sign_btn.TabIndex = 4;
            this.Sign_btn.Text = "登入";
            this.Sign_btn.UseVisualStyleBackColor = true;
            this.Sign_btn.Click += new System.EventHandler(this.Sign_btn_Click);
            // 
            // Password_txt
            // 
            this.Password_txt.Location = new System.Drawing.Point(104, 66);
            this.Password_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Password_txt.Multiline = true;
            this.Password_txt.Name = "Password_txt";
            this.Password_txt.PasswordChar = '●';
            this.Password_txt.Size = new System.Drawing.Size(233, 26);
            this.Password_txt.TabIndex = 3;
            this.Password_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Account_txt
            // 
            this.Account_txt.Font = new System.Drawing.Font("新細明體", 12F);
            this.Account_txt.Location = new System.Drawing.Point(104, 4);
            this.Account_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Account_txt.Multiline = true;
            this.Account_txt.Name = "Account_txt";
            this.Account_txt.Size = new System.Drawing.Size(233, 26);
            this.Account_txt.TabIndex = 2;
            this.Account_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 15F);
            this.label7.Location = new System.Drawing.Point(4, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 25);
            this.label7.TabIndex = 1;
            this.label7.Text = "密碼：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 15F);
            this.label6.Location = new System.Drawing.Point(4, 4);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "帳號：";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 311);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(16, 341);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(1168, 244);
            this.listBox1.TabIndex = 13;
            // 
            // Del
            // 
            this.Del.HeaderText = "刪除";
            this.Del.Name = "Del";
            this.Del.Text = "刪除";
            this.Del.UseColumnTextForButtonValue = true;
            // 
            // StockID
            // 
            this.StockID.DataPropertyName = "股票代號";
            this.StockID.HeaderText = "股票代號";
            this.StockID.Name = "StockID";
            // 
            // Condition
            // 
            this.Condition.DataPropertyName = "條件";
            this.Condition.HeaderText = "條件";
            this.Condition.Name = "Condition";
            // 
            // Price
            // 
            this.Price.DataPropertyName = "價格";
            this.Price.HeaderText = "價格";
            this.Price.Name = "Price";
            // 
            // Quatity
            // 
            this.Quatity.DataPropertyName = "數量(張)";
            this.Quatity.HeaderText = "數量(張)";
            this.Quatity.Name = "Quatity";
            // 
            // Exe
            // 
            this.Exe.DataPropertyName = "執行";
            this.Exe.HeaderText = "執行";
            this.Exe.Name = "Exe";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(98, 308);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 25);
            this.textBox1.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Main_pnl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OPH_er";
            this.Main_pnl.ResumeLayout(false);
            this.Main_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StopLoss_dgv)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Main_pnl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox StockQty_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Stockprice_txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Stockcondition_cmbbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Stockcode_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox StockExe_cmbbx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Add_btn;
        private System.Windows.Forms.DataGridView StopLoss_dgv;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button Sign_btn;
        private System.Windows.Forms.TextBox Password_txt;
        private System.Windows.Forms.TextBox Account_txt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.DataGridViewButtonColumn Del;
        private System.Windows.Forms.DataGridViewTextBoxColumn StockID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Condition;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quatity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Exe;
        private System.Windows.Forms.TextBox textBox1;
    }
}

