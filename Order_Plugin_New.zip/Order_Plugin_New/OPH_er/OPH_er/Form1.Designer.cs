﻿namespace OPH_er
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Main_pnl = new System.Windows.Forms.Panel();
            this.StopLoss_dgv = new System.Windows.Forms.DataGridView();
            this.Setting_GrpBx = new System.Windows.Forms.GroupBox();
            this.OCO_Grpbx = new System.Windows.Forms.GroupBox();
            this.StopLoss_txt = new System.Windows.Forms.TextBox();
            this.StopProfit_txt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Touch_OCO_Grpbx = new System.Windows.Forms.GroupBox();
            this.Stockcode_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.StockExe_cmbbx = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.OrderMethod_cmbbx = new System.Windows.Forms.ComboBox();
            this.Stockcondition_cmbbx = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.StockQty_txt = new System.Windows.Forms.TextBox();
            this.OrderPrice_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Conditionprice_txt = new System.Windows.Forms.TextBox();
            this.Intelligent_Grpbx = new System.Windows.Forms.GroupBox();
            this.OCO_Radio = new System.Windows.Forms.RadioButton();
            this.MIT_Radio = new System.Windows.Forms.RadioButton();
            this.Add_btn = new System.Windows.Forms.Button();
            this.Msg_lst = new System.Windows.Forms.ListBox();
            this.Account_pnl = new System.Windows.Forms.Panel();
            this.Remember_chk = new System.Windows.Forms.CheckBox();
            this.Sign_btn = new System.Windows.Forms.Button();
            this.Password_txt = new System.Windows.Forms.TextBox();
            this.Account_txt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.History = new System.Windows.Forms.Button();
            this.Del = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Order = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StockID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Condition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Condition_Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderMethod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Order_price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quatity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Exe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StopProfit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StopLoss = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StateTwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Main_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StopLoss_dgv)).BeginInit();
            this.Setting_GrpBx.SuspendLayout();
            this.OCO_Grpbx.SuspendLayout();
            this.Touch_OCO_Grpbx.SuspendLayout();
            this.Intelligent_Grpbx.SuspendLayout();
            this.Account_pnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // Main_pnl
            // 
            this.Main_pnl.Controls.Add(this.History);
            this.Main_pnl.Controls.Add(this.StopLoss_dgv);
            this.Main_pnl.Controls.Add(this.Setting_GrpBx);
            this.Main_pnl.Location = new System.Drawing.Point(0, 0);
            this.Main_pnl.Margin = new System.Windows.Forms.Padding(4);
            this.Main_pnl.Name = "Main_pnl";
            this.Main_pnl.Size = new System.Drawing.Size(1348, 674);
            this.Main_pnl.TabIndex = 0;
            this.Main_pnl.Visible = false;
            // 
            // StopLoss_dgv
            // 
            this.StopLoss_dgv.AllowUserToAddRows = false;
            this.StopLoss_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StopLoss_dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Del,
            this.Order,
            this.StockID,
            this.Condition,
            this.Condition_Price,
            this.OrderMethod,
            this.Order_price,
            this.Quatity,
            this.Exe,
            this.State,
            this.StopProfit,
            this.StopLoss,
            this.StateTwo});
            this.StopLoss_dgv.Location = new System.Drawing.Point(16, 446);
            this.StopLoss_dgv.Margin = new System.Windows.Forms.Padding(4);
            this.StopLoss_dgv.Name = "StopLoss_dgv";
            this.StopLoss_dgv.ReadOnly = true;
            this.StopLoss_dgv.RowTemplate.Height = 24;
            this.StopLoss_dgv.Size = new System.Drawing.Size(1324, 220);
            this.StopLoss_dgv.TabIndex = 11;
            this.StopLoss_dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.StopLoss_dgv_CellContentClick);
            // 
            // Setting_GrpBx
            // 
            this.Setting_GrpBx.Controls.Add(this.Touch_OCO_Grpbx);
            this.Setting_GrpBx.Controls.Add(this.Intelligent_Grpbx);
            this.Setting_GrpBx.Font = new System.Drawing.Font("新細明體", 10F);
            this.Setting_GrpBx.Location = new System.Drawing.Point(16, 15);
            this.Setting_GrpBx.Margin = new System.Windows.Forms.Padding(4);
            this.Setting_GrpBx.Name = "Setting_GrpBx";
            this.Setting_GrpBx.Padding = new System.Windows.Forms.Padding(4);
            this.Setting_GrpBx.Size = new System.Drawing.Size(667, 424);
            this.Setting_GrpBx.TabIndex = 0;
            this.Setting_GrpBx.TabStop = false;
            this.Setting_GrpBx.Text = "設定";
            // 
            // OCO_Grpbx
            // 
            this.OCO_Grpbx.Controls.Add(this.StopLoss_txt);
            this.OCO_Grpbx.Controls.Add(this.StopProfit_txt);
            this.OCO_Grpbx.Controls.Add(this.label12);
            this.OCO_Grpbx.Controls.Add(this.label11);
            this.OCO_Grpbx.Font = new System.Drawing.Font("標楷體", 10F);
            this.OCO_Grpbx.Location = new System.Drawing.Point(300, 29);
            this.OCO_Grpbx.Name = "OCO_Grpbx";
            this.OCO_Grpbx.Size = new System.Drawing.Size(338, 107);
            this.OCO_Grpbx.TabIndex = 19;
            this.OCO_Grpbx.TabStop = false;
            this.OCO_Grpbx.Text = "OCO";
            this.OCO_Grpbx.Visible = false;
            // 
            // StopLoss_txt
            // 
            this.StopLoss_txt.Location = new System.Drawing.Point(165, 74);
            this.StopLoss_txt.Name = "StopLoss_txt";
            this.StopLoss_txt.Size = new System.Drawing.Size(105, 27);
            this.StopLoss_txt.TabIndex = 3;
            // 
            // StopProfit_txt
            // 
            this.StopProfit_txt.Location = new System.Drawing.Point(165, 37);
            this.StopProfit_txt.Name = "StopProfit_txt";
            this.StopProfit_txt.Size = new System.Drawing.Size(105, 27);
            this.StopProfit_txt.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(30, 77);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(120, 22);
            this.label12.TabIndex = 1;
            this.label12.Text = "停損價格：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(30, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 22);
            this.label11.TabIndex = 0;
            this.label11.Text = "停利價格：";
            // 
            // Touch_OCO_Grpbx
            // 
            this.Touch_OCO_Grpbx.Controls.Add(this.Stockcode_txt);
            this.Touch_OCO_Grpbx.Controls.Add(this.OCO_Grpbx);
            this.Touch_OCO_Grpbx.Controls.Add(this.label1);
            this.Touch_OCO_Grpbx.Controls.Add(this.Add_btn);
            this.Touch_OCO_Grpbx.Controls.Add(this.StockExe_cmbbx);
            this.Touch_OCO_Grpbx.Controls.Add(this.label5);
            this.Touch_OCO_Grpbx.Controls.Add(this.OrderMethod_cmbbx);
            this.Touch_OCO_Grpbx.Controls.Add(this.Stockcondition_cmbbx);
            this.Touch_OCO_Grpbx.Controls.Add(this.label9);
            this.Touch_OCO_Grpbx.Controls.Add(this.StockQty_txt);
            this.Touch_OCO_Grpbx.Controls.Add(this.OrderPrice_txt);
            this.Touch_OCO_Grpbx.Controls.Add(this.label4);
            this.Touch_OCO_Grpbx.Controls.Add(this.label2);
            this.Touch_OCO_Grpbx.Controls.Add(this.label8);
            this.Touch_OCO_Grpbx.Controls.Add(this.label3);
            this.Touch_OCO_Grpbx.Controls.Add(this.Conditionprice_txt);
            this.Touch_OCO_Grpbx.Font = new System.Drawing.Font("標楷體", 10F);
            this.Touch_OCO_Grpbx.Location = new System.Drawing.Point(13, 109);
            this.Touch_OCO_Grpbx.Name = "Touch_OCO_Grpbx";
            this.Touch_OCO_Grpbx.Size = new System.Drawing.Size(645, 306);
            this.Touch_OCO_Grpbx.TabIndex = 17;
            this.Touch_OCO_Grpbx.TabStop = false;
            this.Touch_OCO_Grpbx.Text = "觸價單 -- OCO";
            // 
            // Stockcode_txt
            // 
            this.Stockcode_txt.Font = new System.Drawing.Font("新細明體", 13F);
            this.Stockcode_txt.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Stockcode_txt.Location = new System.Drawing.Point(165, 37);
            this.Stockcode_txt.Margin = new System.Windows.Forms.Padding(4);
            this.Stockcode_txt.Name = "Stockcode_txt";
            this.Stockcode_txt.Size = new System.Drawing.Size(105, 33);
            this.Stockcode_txt.TabIndex = 1;
            this.Stockcode_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Stockcode_txt.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "股票代號：";
            // 
            // StockExe_cmbbx
            // 
            this.StockExe_cmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StockExe_cmbbx.Font = new System.Drawing.Font("新細明體", 13F);
            this.StockExe_cmbbx.FormattingEnabled = true;
            this.StockExe_cmbbx.Items.AddRange(new object[] {
            "買進",
            "賣出"});
            this.StockExe_cmbbx.Location = new System.Drawing.Point(165, 259);
            this.StockExe_cmbbx.Margin = new System.Windows.Forms.Padding(4);
            this.StockExe_cmbbx.Name = "StockExe_cmbbx";
            this.StockExe_cmbbx.Size = new System.Drawing.Size(105, 30);
            this.StockExe_cmbbx.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 262);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 22);
            this.label5.TabIndex = 9;
            this.label5.Text = "執行買賣：";
            // 
            // OrderMethod_cmbbx
            // 
            this.OrderMethod_cmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.OrderMethod_cmbbx.Font = new System.Drawing.Font("新細明體", 13F);
            this.OrderMethod_cmbbx.FormattingEnabled = true;
            this.OrderMethod_cmbbx.Items.AddRange(new object[] {
            "現股",
            "融資",
            "融券"});
            this.OrderMethod_cmbbx.Location = new System.Drawing.Point(165, 148);
            this.OrderMethod_cmbbx.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.OrderMethod_cmbbx.Name = "OrderMethod_cmbbx";
            this.OrderMethod_cmbbx.Size = new System.Drawing.Size(105, 30);
            this.OrderMethod_cmbbx.TabIndex = 4;
            // 
            // Stockcondition_cmbbx
            // 
            this.Stockcondition_cmbbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Stockcondition_cmbbx.Font = new System.Drawing.Font("新細明體", 13F);
            this.Stockcondition_cmbbx.FormattingEnabled = true;
            this.Stockcondition_cmbbx.IntegralHeight = false;
            this.Stockcondition_cmbbx.ItemHeight = 22;
            this.Stockcondition_cmbbx.Items.AddRange(new object[] {
            "大於等於",
            "小於等於"});
            this.Stockcondition_cmbbx.Location = new System.Drawing.Point(165, 74);
            this.Stockcondition_cmbbx.Margin = new System.Windows.Forms.Padding(4);
            this.Stockcondition_cmbbx.Name = "Stockcondition_cmbbx";
            this.Stockcondition_cmbbx.Size = new System.Drawing.Size(105, 30);
            this.Stockcondition_cmbbx.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(30, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 22);
            this.label9.TabIndex = 15;
            this.label9.Text = "掛單方法：";
            // 
            // StockQty_txt
            // 
            this.StockQty_txt.Font = new System.Drawing.Font("新細明體", 13F);
            this.StockQty_txt.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.StockQty_txt.Location = new System.Drawing.Point(165, 222);
            this.StockQty_txt.Margin = new System.Windows.Forms.Padding(4);
            this.StockQty_txt.Name = "StockQty_txt";
            this.StockQty_txt.Size = new System.Drawing.Size(105, 33);
            this.StockQty_txt.TabIndex = 6;
            this.StockQty_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OrderPrice_txt
            // 
            this.OrderPrice_txt.Font = new System.Drawing.Font("新細明體", 13F);
            this.OrderPrice_txt.Location = new System.Drawing.Point(165, 185);
            this.OrderPrice_txt.Margin = new System.Windows.Forms.Padding(4);
            this.OrderPrice_txt.Name = "OrderPrice_txt";
            this.OrderPrice_txt.Size = new System.Drawing.Size(105, 33);
            this.OrderPrice_txt.TabIndex = 5;
            this.OrderPrice_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(30, 225);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 22);
            this.label4.TabIndex = 6;
            this.label4.Text = "數量(張)：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 77);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "觸發條件：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(30, 188);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 22);
            this.label8.TabIndex = 14;
            this.label8.Text = "掛單價格：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("標楷體", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 114);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 22);
            this.label3.TabIndex = 4;
            this.label3.Text = "觸發價格：";
            // 
            // Conditionprice_txt
            // 
            this.Conditionprice_txt.Font = new System.Drawing.Font("新細明體", 13F);
            this.Conditionprice_txt.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Conditionprice_txt.Location = new System.Drawing.Point(165, 111);
            this.Conditionprice_txt.Margin = new System.Windows.Forms.Padding(4);
            this.Conditionprice_txt.Name = "Conditionprice_txt";
            this.Conditionprice_txt.Size = new System.Drawing.Size(105, 33);
            this.Conditionprice_txt.TabIndex = 3;
            this.Conditionprice_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Intelligent_Grpbx
            // 
            this.Intelligent_Grpbx.Controls.Add(this.OCO_Radio);
            this.Intelligent_Grpbx.Controls.Add(this.MIT_Radio);
            this.Intelligent_Grpbx.Font = new System.Drawing.Font("標楷體", 10F);
            this.Intelligent_Grpbx.Location = new System.Drawing.Point(13, 32);
            this.Intelligent_Grpbx.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Intelligent_Grpbx.Name = "Intelligent_Grpbx";
            this.Intelligent_Grpbx.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Intelligent_Grpbx.Size = new System.Drawing.Size(645, 72);
            this.Intelligent_Grpbx.TabIndex = 16;
            this.Intelligent_Grpbx.TabStop = false;
            this.Intelligent_Grpbx.Text = "智慧單";
            // 
            // OCO_Radio
            // 
            this.OCO_Radio.AutoSize = true;
            this.OCO_Radio.Font = new System.Drawing.Font("標楷體", 13F);
            this.OCO_Radio.Location = new System.Drawing.Point(300, 38);
            this.OCO_Radio.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.OCO_Radio.Name = "OCO_Radio";
            this.OCO_Radio.Size = new System.Drawing.Size(339, 26);
            this.OCO_Radio.TabIndex = 1;
            this.OCO_Radio.Text = "OCO ( One Cancel the Other )";
            this.OCO_Radio.UseVisualStyleBackColor = true;
            // 
            // MIT_Radio
            // 
            this.MIT_Radio.AutoSize = true;
            this.MIT_Radio.Checked = true;
            this.MIT_Radio.Font = new System.Drawing.Font("標楷體", 13F);
            this.MIT_Radio.Location = new System.Drawing.Point(30, 38);
            this.MIT_Radio.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MIT_Radio.Name = "MIT_Radio";
            this.MIT_Radio.Size = new System.Drawing.Size(185, 26);
            this.MIT_Radio.TabIndex = 0;
            this.MIT_Radio.TabStop = true;
            this.MIT_Radio.Text = "觸價單 ( MIT )";
            this.MIT_Radio.UseVisualStyleBackColor = true;
            this.MIT_Radio.CheckedChanged += new System.EventHandler(this.MIT_Radio_CheckedChanged);
            // 
            // Add_btn
            // 
            this.Add_btn.Font = new System.Drawing.Font("新細明體", 13F);
            this.Add_btn.Location = new System.Drawing.Point(300, 229);
            this.Add_btn.Margin = new System.Windows.Forms.Padding(4);
            this.Add_btn.Name = "Add_btn";
            this.Add_btn.Size = new System.Drawing.Size(338, 65);
            this.Add_btn.TabIndex = 8;
            this.Add_btn.Text = "新增";
            this.Add_btn.UseVisualStyleBackColor = true;
            this.Add_btn.Click += new System.EventHandler(this.Add_btn_Click);
            // 
            // Msg_lst
            // 
            this.Msg_lst.FormattingEnabled = true;
            this.Msg_lst.ItemHeight = 15;
            this.Msg_lst.Location = new System.Drawing.Point(16, 679);
            this.Msg_lst.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Msg_lst.Name = "Msg_lst";
            this.Msg_lst.Size = new System.Drawing.Size(1323, 94);
            this.Msg_lst.TabIndex = 13;
            // 
            // Account_pnl
            // 
            this.Account_pnl.Controls.Add(this.Remember_chk);
            this.Account_pnl.Controls.Add(this.Sign_btn);
            this.Account_pnl.Controls.Add(this.Password_txt);
            this.Account_pnl.Controls.Add(this.Account_txt);
            this.Account_pnl.Controls.Add(this.label7);
            this.Account_pnl.Controls.Add(this.label6);
            this.Account_pnl.Location = new System.Drawing.Point(453, 226);
            this.Account_pnl.Margin = new System.Windows.Forms.Padding(4);
            this.Account_pnl.Name = "Account_pnl";
            this.Account_pnl.Size = new System.Drawing.Size(452, 132);
            this.Account_pnl.TabIndex = 1;
            // 
            // Remember_chk
            // 
            this.Remember_chk.AutoSize = true;
            this.Remember_chk.Font = new System.Drawing.Font("新細明體", 15F);
            this.Remember_chk.Location = new System.Drawing.Point(104, 101);
            this.Remember_chk.Margin = new System.Windows.Forms.Padding(4);
            this.Remember_chk.Name = "Remember_chk";
            this.Remember_chk.Size = new System.Drawing.Size(134, 29);
            this.Remember_chk.TabIndex = 5;
            this.Remember_chk.Text = "記住帳號";
            this.Remember_chk.UseVisualStyleBackColor = true;
            // 
            // Sign_btn
            // 
            this.Sign_btn.Font = new System.Drawing.Font("新細明體", 15F);
            this.Sign_btn.Location = new System.Drawing.Point(347, 5);
            this.Sign_btn.Margin = new System.Windows.Forms.Padding(4);
            this.Sign_btn.Name = "Sign_btn";
            this.Sign_btn.Size = new System.Drawing.Size(100, 89);
            this.Sign_btn.TabIndex = 3;
            this.Sign_btn.Text = "登入";
            this.Sign_btn.UseVisualStyleBackColor = true;
            this.Sign_btn.Click += new System.EventHandler(this.Sign_btn_Click);
            // 
            // Password_txt
            // 
            this.Password_txt.Font = new System.Drawing.Font("新細明體", 9F);
            this.Password_txt.Location = new System.Drawing.Point(104, 62);
            this.Password_txt.Margin = new System.Windows.Forms.Padding(4);
            this.Password_txt.Name = "Password_txt";
            this.Password_txt.PasswordChar = '●';
            this.Password_txt.Size = new System.Drawing.Size(233, 25);
            this.Password_txt.TabIndex = 2;
            this.Password_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Password_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Password_txt_KeyDown);
            // 
            // Account_txt
            // 
            this.Account_txt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Account_txt.Font = new System.Drawing.Font("新細明體", 9F);
            this.Account_txt.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Account_txt.Location = new System.Drawing.Point(104, 5);
            this.Account_txt.Margin = new System.Windows.Forms.Padding(4);
            this.Account_txt.Name = "Account_txt";
            this.Account_txt.Size = new System.Drawing.Size(233, 25);
            this.Account_txt.TabIndex = 1;
            this.Account_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Account_txt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Account_txt_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 15F);
            this.label7.Location = new System.Drawing.Point(4, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 25);
            this.label7.TabIndex = 1;
            this.label7.Text = "密碼：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 15F);
            this.label6.Location = new System.Drawing.Point(4, 4);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "帳號：";
            // 
            // History
            // 
            this.History.Location = new System.Drawing.Point(1240, 12);
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(100, 34);
            this.History.TabIndex = 20;
            this.History.Text = "載入歷史";
            this.History.UseVisualStyleBackColor = true;
            this.History.Click += new System.EventHandler(this.History_Click);
            // 
            // Del
            // 
            this.Del.HeaderText = "刪除";
            this.Del.Name = "Del";
            this.Del.ReadOnly = true;
            this.Del.Text = "刪除";
            this.Del.UseColumnTextForButtonValue = true;
            // 
            // Order
            // 
            this.Order.DataPropertyName = "種類";
            this.Order.HeaderText = "種類";
            this.Order.Name = "Order";
            this.Order.ReadOnly = true;
            // 
            // StockID
            // 
            this.StockID.DataPropertyName = "股票代號";
            this.StockID.HeaderText = "股票代號";
            this.StockID.Name = "StockID";
            this.StockID.ReadOnly = true;
            // 
            // Condition
            // 
            this.Condition.DataPropertyName = "條件";
            this.Condition.HeaderText = "條件";
            this.Condition.Name = "Condition";
            this.Condition.ReadOnly = true;
            // 
            // Condition_Price
            // 
            this.Condition_Price.DataPropertyName = "價格";
            this.Condition_Price.HeaderText = "價格";
            this.Condition_Price.Name = "Condition_Price";
            this.Condition_Price.ReadOnly = true;
            // 
            // OrderMethod
            // 
            this.OrderMethod.DataPropertyName = "方法";
            this.OrderMethod.HeaderText = "方法";
            this.OrderMethod.Name = "OrderMethod";
            this.OrderMethod.ReadOnly = true;
            // 
            // Order_price
            // 
            this.Order_price.DataPropertyName = "掛單價格";
            this.Order_price.HeaderText = "掛單價格";
            this.Order_price.Name = "Order_price";
            this.Order_price.ReadOnly = true;
            // 
            // Quatity
            // 
            this.Quatity.DataPropertyName = "數量(張)";
            this.Quatity.HeaderText = "數量(張)";
            this.Quatity.Name = "Quatity";
            this.Quatity.ReadOnly = true;
            // 
            // Exe
            // 
            this.Exe.DataPropertyName = "執行";
            this.Exe.HeaderText = "執行";
            this.Exe.Name = "Exe";
            this.Exe.ReadOnly = true;
            // 
            // State
            // 
            this.State.DataPropertyName = "狀態(1)";
            this.State.HeaderText = "狀態(1)";
            this.State.Name = "State";
            this.State.ReadOnly = true;
            // 
            // StopProfit
            // 
            this.StopProfit.DataPropertyName = "停利價格";
            this.StopProfit.HeaderText = "停利價格";
            this.StopProfit.Name = "StopProfit";
            this.StopProfit.ReadOnly = true;
            // 
            // StopLoss
            // 
            this.StopLoss.DataPropertyName = "停損價格";
            this.StopLoss.HeaderText = "停損價格";
            this.StopLoss.Name = "StopLoss";
            this.StopLoss.ReadOnly = true;
            // 
            // StateTwo
            // 
            this.StateTwo.DataPropertyName = "狀態(2)";
            this.StateTwo.HeaderText = "狀態(2)";
            this.StateTwo.Name = "StateTwo";
            this.StateTwo.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1356, 779);
            this.Controls.Add(this.Main_pnl);
            this.Controls.Add(this.Msg_lst);
            this.Controls.Add(this.Account_pnl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " OPH_er";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Main_pnl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.StopLoss_dgv)).EndInit();
            this.Setting_GrpBx.ResumeLayout(false);
            this.OCO_Grpbx.ResumeLayout(false);
            this.OCO_Grpbx.PerformLayout();
            this.Touch_OCO_Grpbx.ResumeLayout(false);
            this.Touch_OCO_Grpbx.PerformLayout();
            this.Intelligent_Grpbx.ResumeLayout(false);
            this.Intelligent_Grpbx.PerformLayout();
            this.Account_pnl.ResumeLayout(false);
            this.Account_pnl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Main_pnl;
        private System.Windows.Forms.GroupBox Setting_GrpBx;
        private System.Windows.Forms.TextBox StockQty_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Conditionprice_txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Stockcondition_cmbbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Stockcode_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox StockExe_cmbbx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Add_btn;
        private System.Windows.Forms.DataGridView StopLoss_dgv;
        private System.Windows.Forms.Panel Account_pnl;
        private System.Windows.Forms.CheckBox Remember_chk;
        private System.Windows.Forms.Button Sign_btn;
        private System.Windows.Forms.TextBox Password_txt;
        private System.Windows.Forms.TextBox Account_txt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox Msg_lst;
        private System.Windows.Forms.TextBox OrderPrice_txt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox OrderMethod_cmbbx;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox Intelligent_Grpbx;
        private System.Windows.Forms.RadioButton OCO_Radio;
        private System.Windows.Forms.RadioButton MIT_Radio;
        private System.Windows.Forms.GroupBox Touch_OCO_Grpbx;
        private System.Windows.Forms.GroupBox OCO_Grpbx;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox StopLoss_txt;
        private System.Windows.Forms.TextBox StopProfit_txt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button History;
        private System.Windows.Forms.DataGridViewButtonColumn Del;
        private System.Windows.Forms.DataGridViewTextBoxColumn Order;
        private System.Windows.Forms.DataGridViewTextBoxColumn StockID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Condition;
        private System.Windows.Forms.DataGridViewTextBoxColumn Condition_Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderMethod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Order_price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quatity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Exe;
        private System.Windows.Forms.DataGridViewTextBoxColumn State;
        private System.Windows.Forms.DataGridViewTextBoxColumn StopProfit;
        private System.Windows.Forms.DataGridViewTextBoxColumn StopLoss;
        private System.Windows.Forms.DataGridViewTextBoxColumn StateTwo;
    }
}

