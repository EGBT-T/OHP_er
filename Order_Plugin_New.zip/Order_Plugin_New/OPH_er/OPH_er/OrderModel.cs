﻿namespace OPH_er
{
    class OrderModel
    {
        public string Order()
        {

            return "1";
        }
    }
}
